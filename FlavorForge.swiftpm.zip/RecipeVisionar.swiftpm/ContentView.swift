import SwiftUI

struct ContentView: View {
    @StateObject private var manager = RecipeManager()
    
    var body: some View {
        TabView {
            CookBoxView()
                .tabItem { Label("Cook Box", systemImage: "frying.pan") }
            
            RecipeCreatorView()
                .tabItem { Label("Create", systemImage: "wand.and.stars") }
            
            MyRecipesView()
                .tabItem { Label("My Recipes", systemImage: "book.closed") }
        }
        // we set it to orange since blue violate the food color law:
        .tint(.orange)
        
        .environmentObject(manager)
    }
}
