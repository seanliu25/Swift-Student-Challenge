import SwiftUI

@main
struct RecipeVisionarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
