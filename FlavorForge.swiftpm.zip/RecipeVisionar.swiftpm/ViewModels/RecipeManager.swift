import SwiftUI

class RecipeManager: ObservableObject {
    @Published var potIngredients: [IngredientItem] = []
//    hold an array of recipes:
    @Published var suggestedRecipes: [Recipe] = []
    // We start empty and load from defaults
    @Published var recipeDatabase: [Recipe] = []
    
    // A signal to reset navigation back to the main screen
    @Published var resetNavigation = false
    
    // The base recipes that come with the app
    let defaultRecipes: [Recipe] = [
            
            // MARK: - 🔥 THE GRILL (5 Recipes)
            Recipe(
                name: "Ribeye Steak",
                requiredIngredients: ["Beef", "Garlic"],
                method: "Grill",
                emoji: "🥩",
                cookTime: 10,
                seasoningsBefore: ["Salt 🧂", "Pepper 🌶️", "Olive Oil 🫒"],
                seasoningsAfter: ["Garlic Powder 🧄"],
                ingredientPreps: [
                    IngredientPrep(name: "Beef", cutStyle: "None", preSeason: true),
                    IngredientPrep(name: "Garlic", cutStyle: "Smash", preSeason: false)
                ],
                cookPhases: [
                    CookPhase(ingredients: ["Beef"], cookTime: 8),
                    CookPhase(ingredients: ["Garlic"], cookTime: 2)
                ],
                notes: ["Let the steak rest for 5 minutes after grilling to lock in juices!", "Make sure the grill is screaming hot."]
            ),
            Recipe(
                name: "Grilled Salmon",
                requiredIngredients: ["Salmon", "Lemon", "Garlic"],
                method: "Grill",
                emoji: "🍣",
                cookTime: 12,
                seasoningsBefore: ["Olive Oil 🫒", "Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Salmon", cutStyle: "None", preSeason: true),
                    IngredientPrep(name: "Lemon", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Garlic", cutStyle: "Mince", preSeason: false)
                ]
            ),
            Recipe(
                name: "Cheeseburger",
                requiredIngredients: ["Beef", "Cheese", "Bread", "Tomato", "Lettuce"],
                method: "Grill",
                emoji: "🍔",
                cookTime: 8,
                seasoningsDuring: ["Salt 🧂", "Pepper 🌶️"],
                ingredientPreps: [
                    IngredientPrep(name: "Beef", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Tomato", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Lettuce", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Bread", cutStyle: "Halve", preSeason: false),
                    IngredientPrep(name: "Cheese", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "BBQ Pork Chops",
                requiredIngredients: ["Pork", "Onion"],
                method: "Grill",
                emoji: "🍖",
                cookTime: 14,
                seasoningsBefore: ["Honey 🍯", "Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Pork", cutStyle: "None", preSeason: true),
                    IngredientPrep(name: "Onion", cutStyle: "Slice", preSeason: false)
                ]
            ),
            Recipe(
                name: "Grilled Veggies",
                requiredIngredients: ["Eggplant", "Mushroom", "Bell Pepper"],
                method: "Grill",
                emoji: "🥗",
                cookTime: 10,
                seasoningsAfter: ["Olive Oil 🫒", "Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Eggplant", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Mushroom", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Bell Pepper", cutStyle: "Chop", preSeason: false)
                ]
            ),

            // MARK: - 🍳 THE FRYING PAN (10 Recipes)
            Recipe(
                name: "Kung Pao Chicken",
                requiredIngredients: ["Chicken", "Onion", "Garlic", "Peanut", "Chili Pepper"],
                method: "Fry",
                emoji: "🥡",
                cookTime: 12,
                seasoningsBefore: ["Soy Sauce 🫙"],
                ingredientPreps: [
                    IngredientPrep(name: "Chicken", cutStyle: "Dice", preSeason: true),
                    IngredientPrep(name: "Onion", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Garlic", cutStyle: "Smash", preSeason: false),
                    IngredientPrep(name: "Peanut", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Chili Pepper", cutStyle: "Chop", preSeason: false)
                ],
                cookPhases: [
                    CookPhase(ingredients: ["Garlic", "Chili Pepper", "Onion"], cookTime: 3),
                    CookPhase(ingredients: ["Chicken"], cookTime: 7),
                    CookPhase(ingredients: ["Peanut"], cookTime: 2)
                ],
                notes: ["Keep the wok very hot and keep tossing!"]
            ),
            Recipe(
                name: "Fried Rice",
                requiredIngredients: ["Rice", "Egg", "Carrot", "Onion"],
                method: "Fry",
                emoji: "🍛",
                cookTime: 10,
                seasoningsDuring: ["Soy Sauce 🫙", "Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Carrot", cutStyle: "Dice", preSeason: false),
                    IngredientPrep(name: "Onion", cutStyle: "Dice", preSeason: false),
                    IngredientPrep(name: "Egg", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Rice", cutStyle: "None", preSeason: false)
                ],
                cookPhases: [
                    CookPhase(ingredients: ["Egg"], cookTime: 2),
                    CookPhase(ingredients: ["Carrot", "Onion"], cookTime: 3),
                    CookPhase(ingredients: ["Rice"], cookTime: 5)
                ],
                notes: ["Day-old cold rice works best so it doesn't get mushy!"]
            ),
            Recipe(
                name: "Beef Stir Fry",
                requiredIngredients: ["Beef", "Broccoli", "Ginger", "Onion"],
                method: "Fry",
                emoji: "🥘",
                cookTime: 11,
                seasoningsBefore: ["Soy Sauce 🫙"],
                ingredientPreps: [
                    IngredientPrep(name: "Beef", cutStyle: "Slice", preSeason: true),
                    IngredientPrep(name: "Broccoli", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Ginger", cutStyle: "Mince", preSeason: false),
                    IngredientPrep(name: "Onion", cutStyle: "Slice", preSeason: false)
                ]
            ),
            Recipe(
                name: "Spicy Octopus",
                requiredIngredients: ["Octopus", "Chili Pepper", "Garlic"],
                method: "Fry",
                emoji: "🐙",
                cookTime: 8,
                seasoningsDuring: ["Soy Sauce 🫙"],
                ingredientPreps: [
                    IngredientPrep(name: "Octopus", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Chili Pepper", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Garlic", cutStyle: "Mince", preSeason: false)
                ]
            ),
            Recipe(
                name: "Shrimp Noodles",
                requiredIngredients: ["Noodles", "Shrimp", "Carrot"],
                method: "Fry",
                emoji: "🍜",
                cookTime: 9,
                seasoningsDuring: ["Soy Sauce 🫙", "Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Noodles", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Shrimp", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Carrot", cutStyle: "Slice", preSeason: false)
                ]
            ),
            Recipe(
                name: "Shakshuka",
                requiredIngredients: ["Tomato", "Egg", "Onion", "Bell Pepper"],
                method: "Fry",
                emoji: "🍳",
                cookTime: 12,
                seasoningsDuring: ["Salt 🧂", "Pepper 🌶️"],
                ingredientPreps: [
                    IngredientPrep(name: "Tomato", cutStyle: "Dice", preSeason: false),
                    IngredientPrep(name: "Onion", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Bell Pepper", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Egg", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Potato Omelette",
                requiredIngredients: ["Potato", "Egg", "Onion"],
                method: "Fry",
                emoji: "🥔",
                cookTime: 15,
                seasoningsDuring: ["Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Potato", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Onion", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Egg", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "BLT Sandwich",
                requiredIngredients: ["Bacon", "Bread", "Tomato", "Lettuce"],
                method: "Fry",
                emoji: "🥪",
                cookTime: 6,
                ingredientPreps: [
                    IngredientPrep(name: "Bacon", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Bread", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Tomato", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Lettuce", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Avocado Toast",
                requiredIngredients: ["Bread", "Avocado", "Egg"],
                method: "Fry",
                emoji: "🥑",
                cookTime: 5,
                seasoningsAfter: ["Salt 🧂", "Pepper 🌶️"],
                ingredientPreps: [
                    IngredientPrep(name: "Bread", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Avocado", cutStyle: "Smash", preSeason: false),
                    IngredientPrep(name: "Egg", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Chicken Tacos",
                requiredIngredients: ["Chicken", "Taco Shell", "Cheese", "Lettuce"],
                method: "Fry",
                emoji: "🌮",
                cookTime: 10,
                seasoningsDuring: ["Salt 🧂", "Chili Pepper 🌶️"],
                ingredientPreps: [
                    IngredientPrep(name: "Chicken", cutStyle: "Dice", preSeason: false),
                    IngredientPrep(name: "Taco Shell", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Cheese", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Lettuce", cutStyle: "Chop", preSeason: false)
                ]
            ),

            // MARK: - ♨️ THE STEAMER (4 Recipes)
            Recipe(
                name: "Steamed Dumplings",
                requiredIngredients: ["Dumpling"],
                method: "Steam",
                emoji: "🥟",
                cookTime: 12,
                seasoningsAfter: ["Soy Sauce 🫙"],
                ingredientPreps: [ IngredientPrep(name: "Dumpling", cutStyle: "None", preSeason: false) ]
            ),
            Recipe(
                name: "Steamed Fish",
                requiredIngredients: ["Fish", "Ginger", "Onion"],
                method: "Steam",
                emoji: "🐟",
                cookTime: 15,
                seasoningsBefore: ["Soy Sauce 🫙"],
                ingredientPreps: [
                    IngredientPrep(name: "Fish", cutStyle: "None", preSeason: true),
                    IngredientPrep(name: "Ginger", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Onion", cutStyle: "Slice", preSeason: false)
                ]
            ),
            Recipe(
                name: "Steamed Veggies",
                requiredIngredients: ["Broccoli", "Carrot"],
                method: "Steam",
                emoji: "🥦",
                cookTime: 10,
                seasoningsAfter: ["Olive Oil 🫒", "Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Broccoli", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Carrot", cutStyle: "Slice", preSeason: false)
                ]
            ),
            Recipe(
                name: "Steamed Sweet Potato",
                requiredIngredients: ["Rice", "Sweet Potato"],
                method: "Steam",
                emoji: "🍠",
                cookTime: 18,
                ingredientPreps: [
                    IngredientPrep(name: "Rice", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Sweet Potato", cutStyle: "Slice", preSeason: false)
                ]
            ),

            // MARK: - 🍲 THE BOILING POT (6 Recipes)
            Recipe(
                name: "Spaghetti Bolognese",
                requiredIngredients: ["Pasta", "Beef", "Tomato", "Garlic"],
                method: "Boil",
                emoji: "🍝",
                cookTime: 20,
                seasoningsDuring: ["Salt 🧂", "Olive Oil 🫒"],
                ingredientPreps: [
                    IngredientPrep(name: "Pasta", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Beef", cutStyle: "Mince", preSeason: false),
                    IngredientPrep(name: "Tomato", cutStyle: "Dice", preSeason: false),
                    IngredientPrep(name: "Garlic", cutStyle: "Mince", preSeason: false)
                ]
            ),
            Recipe(
                name: "Mushroom Risotto",
                requiredIngredients: ["Rice", "Mushroom", "Cheese", "Garlic"],
                method: "Boil",
                emoji: "🥘",
                cookTime: 25,
                seasoningsAfter: ["Pepper 🌶️"],
                ingredientPreps: [
                    IngredientPrep(name: "Rice", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Mushroom", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Cheese", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Garlic", cutStyle: "Mince", preSeason: false)
                ],
                notes: ["Stir continuously to release the starches!"]
            ),
            Recipe(
                name: "Mac and Cheese",
                requiredIngredients: ["Pasta", "Melted Cheese", "Milk"],
                method: "Boil",
                emoji: "🧀",
                cookTime: 12,
                seasoningsDuring: ["Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Pasta", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Melted Cheese", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Milk", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Chicken Soup",
                requiredIngredients: ["Chicken", "Carrot", "Onion", "Broth"],
                method: "Boil",
                emoji: "🥣",
                cookTime: 35,
                seasoningsDuring: ["Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Chicken", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Carrot", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Onion", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Broth", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Tomato Soup",
                requiredIngredients: ["Tomato", "Garlic", "Broth"],
                method: "Boil",
                emoji: "🍅",
                cookTime: 20,
                ingredientPreps: [
                    IngredientPrep(name: "Tomato", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Garlic", cutStyle: "Smash", preSeason: false),
                    IngredientPrep(name: "Broth", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Veggie Stew",
                requiredIngredients: ["Potato", "Carrot", "Peas", "Onion"],
                method: "Boil",
                emoji: "🍲",
                cookTime: 30,
                seasoningsDuring: ["Salt 🧂", "Pepper 🌶️"],
                ingredientPreps: [
                    IngredientPrep(name: "Potato", cutStyle: "Chop", preSeason: false),
                    IngredientPrep(name: "Carrot", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Peas", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Onion", cutStyle: "Chop", preSeason: false)
                ]
            ),

            // MARK: - 🎛️ THE OVEN (5 Recipes)
            Recipe(
                name: "Chicken Parmesan",
                requiredIngredients: ["Chicken", "Tomato", "Melted Cheese"],
                method: "Bake",
                emoji: "🍗",
                cookTime: 25,
                seasoningsBefore: ["Salt 🧂"],
                ingredientPreps: [
                    IngredientPrep(name: "Chicken", cutStyle: "Halve", preSeason: true),
                    IngredientPrep(name: "Tomato", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Melted Cheese", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Garlic Baguette",
                requiredIngredients: ["Baguette", "Garlic", "Butter"],
                method: "Bake",
                emoji: "🥖",
                cookTime: 10,
                seasoningsAfter: ["Olive Oil 🫒"],
                ingredientPreps: [
                    IngredientPrep(name: "Baguette", cutStyle: "Slice", preSeason: false),
                    IngredientPrep(name: "Garlic", cutStyle: "Smash", preSeason: false),
                    IngredientPrep(name: "Butter", cutStyle: "None", preSeason: false)
                ]
            ),
            Recipe(
                name: "Baked Apple",
                requiredIngredients: ["Red Apple", "Butter"],
                method: "Bake",
                emoji: "🍎",
                cookTime: 25,
                seasoningsBefore: ["Honey 🍯", "Maple Syrup 🍁"],
                ingredientPreps: [
                    IngredientPrep(name: "Red Apple", cutStyle: "Halve", preSeason: true),
                    IngredientPrep(name: "Butter", cutStyle: "None", preSeason: false)
                ],
                notes: ["Core the apple before filling it with butter and honey!"]
            ),
            Recipe(
                name: "Chocolate Croissant",
                requiredIngredients: ["Croissant", "Chocolate"],
                method: "Bake",
                emoji: "🥐",
                cookTime: 12,
                ingredientPreps: [
                    IngredientPrep(name: "Croissant", cutStyle: "Halve", preSeason: false),
                    IngredientPrep(name: "Chocolate", cutStyle: "Smash", preSeason: false)
                ]
            ),
            Recipe(
                name: "Beef Burrito",
                requiredIngredients: ["Beef", "Tortilla", "Beans", "Cheese"],
                method: "Bake",
                emoji: "🌯",
                cookTime: 15,
                seasoningsDuring: ["Chili Pepper 🌶️"],
                ingredientPreps: [
                    IngredientPrep(name: "Beef", cutStyle: "Mince", preSeason: false),
                    IngredientPrep(name: "Tortilla", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Beans", cutStyle: "None", preSeason: false),
                    IngredientPrep(name: "Cheese", cutStyle: "None", preSeason: false)
                ]
            )
        ]
    
    // We create an array for the Creator UI
        let ingredientCategories: [IngredientCategory] = [
            IngredientCategory(name: "🥬 Veggies & Aromatics", items: [
                IngredientItem(name: "Tomato", emoji: "🍅", color: .red),
                IngredientItem(name: "Potato", emoji: "🥔", color: .brown),
                IngredientItem(name: "Carrot", emoji: "🥕", color: .orange),
                IngredientItem(name: "Onion", emoji: "🧅", color: .purple),
                IngredientItem(name: "Garlic", emoji: "🧄", color: .gray),
                IngredientItem(name: "Mushroom", emoji: "🍄", color: .brown),
                IngredientItem(name: "Broccoli", emoji: "🥦", color: .green),
                IngredientItem(name: "Bell Pepper", emoji: "🫑", color: .green),
                IngredientItem(name: "Chili Pepper", emoji: "🌶️", color: .red),
                IngredientItem(name: "Corn", emoji: "🌽", color: .yellow),
                IngredientItem(name: "Avocado", emoji: "🥑", color: .green),
                IngredientItem(name: "Eggplant", emoji: "🍆", color: .purple),
                IngredientItem(name: "Cucumber", emoji: "🥒", color: .green),
                IngredientItem(name: "Lettuce", emoji: "🥬", color: .green),
                IngredientItem(name: "Sweet Potato", emoji: "🍠", color: .orange),
                IngredientItem(name: "Ginger", emoji: "🫚", color: .brown),
                IngredientItem(name: "Peas", emoji: "🫛", color: .green),
                IngredientItem(name: "Olive", emoji: "🫒", color: .green)
            ]),
            IngredientCategory(name: "🍎 Fruits & Citrus", items: [
                IngredientItem(name: "Lemon", emoji: "🍋", color: .yellow),
                IngredientItem(name: "Lime", emoji: "🍋‍🟩", color: .green),
                IngredientItem(name: "Red Apple", emoji: "🍎", color: .red),
                IngredientItem(name: "Green Apple", emoji: "🍏", color: .green),
                IngredientItem(name: "Orange", emoji: "🍊", color: .orange),
                IngredientItem(name: "Banana", emoji: "🍌", color: .yellow),
                IngredientItem(name: "Pineapple", emoji: "🍍", color: .yellow),
                IngredientItem(name: "Strawberry", emoji: "🍓", color: .red),
                IngredientItem(name: "Blueberry", emoji: "🫐", color: .blue),
                IngredientItem(name: "Grapes", emoji: "🍇", color: .purple),
                IngredientItem(name: "Peach", emoji: "🍑", color: .orange),
                IngredientItem(name: "Cherry", emoji: "🍒", color: .red),
                IngredientItem(name: "Watermelon", emoji: "🍉", color: .red),
                IngredientItem(name: "Melon", emoji: "🍈", color: .green),
                IngredientItem(name: "Coconut", emoji: "🥥", color: .brown),
                IngredientItem(name: "Mango", emoji: "🥭", color: .orange),
                IngredientItem(name: "Kiwi", emoji: "🥝", color: .green),
                IngredientItem(name: "Pear", emoji: "🍐", color: .green),
                IngredientItem(name: "Peanut", emoji: "🥜", color: .green)
                
            ]),
            IngredientCategory(name: "🥚 Dairy & Eggs", items: [
                IngredientItem(name: "Egg", emoji: "🥚", color: .yellow),
                IngredientItem(name: "Cheese", emoji: "🧀", color: .yellow),
                IngredientItem(name: "Milk", emoji: "🥛", color: .white),
                IngredientItem(name: "Butter", emoji: "🧈", color: .yellow),
                IngredientItem(name: "Ice Cream", emoji: "🍦", color: .white),
                IngredientItem(name: "Melted Cheese", emoji: "🫕", color: .yellow)
            ]),
            IngredientCategory(name: "🥩 Meats & Poultry", items: [
                IngredientItem(name: "Beef", emoji: "🥩", color: .red),
                IngredientItem(name: "Chicken", emoji: "🍗", color: .orange),
                IngredientItem(name: "Bacon", emoji: "🥓", color: .pink),
                IngredientItem(name: "Pork", emoji: "🍖", color: .brown),
                IngredientItem(name: "Sausage", emoji: "🌭", color: .brown),
                IngredientItem(name: "Turkey", emoji: "🦃", color: .brown),
                IngredientItem(name: "Duck", emoji: "🦆", color: .brown)
            ]),
            IngredientCategory(name: "🍤 Seafood", items: [
                IngredientItem(name: "Fish", emoji: "🐟", color: .blue),
                IngredientItem(name: "Shrimp", emoji: "🍤", color: .orange),
                IngredientItem(name: "Salmon", emoji: "🍣", color: .orange),
                IngredientItem(name: "Crab", emoji: "🦀", color: .red),
                IngredientItem(name: "Lobster", emoji: "🦞", color: .red),
                IngredientItem(name: "Squid", emoji: "🦑", color: .purple),
                IngredientItem(name: "Octopus", emoji: "🐙", color: .purple),
                IngredientItem(name: "Oyster", emoji: "🦪", color: .gray)
            ]),
            IngredientCategory(name: "🍝 Carbs, Grains & Breads", items: [
                IngredientItem(name: "Rice", emoji: "🍚", color: .white),
                IngredientItem(name: "Pasta", emoji: "🍝", color: .yellow),
                IngredientItem(name: "Bread", emoji: "🍞", color: .brown),
                IngredientItem(name: "Baguette", emoji: "🥖", color: .brown),
                IngredientItem(name: "Croissant", emoji: "🥐", color: .brown),
                IngredientItem(name: "Flour", emoji: "🌾", color: .white),
                IngredientItem(name: "Noodles", emoji: "🍜", color: .yellow),
                IngredientItem(name: "Flatbread", emoji: "🫓", color: .brown),
                IngredientItem(name: "Pretzel", emoji: "🥨", color: .brown),
                IngredientItem(name: "Bagel", emoji: "🥯", color: .brown),
                IngredientItem(name: "Pancake", emoji: "🥞", color: .yellow),
                IngredientItem(name: "Waffle", emoji: "🧇", color: .yellow),
                IngredientItem(name: "Dumpling", emoji: "🥟", color: .white),
                IngredientItem(name: "Taco Shell", emoji: "🌮", color: .yellow),
                IngredientItem(name: "Tortilla", emoji: "🌯", color: .yellow),
                IngredientItem(name: "Pizza Dough", emoji: "🍕", color: .yellow),
                IngredientItem(name: "Rice Cracker", emoji: "🍘", color: .brown),
                IngredientItem(name: "Broth", emoji: "🥫", color: .brown),
                IngredientItem(name: "Chocolate", emoji: "🍫", color: .brown)
                
            ])
        ]

        // Automatically flattens the categories back into a single list!
        // This ensures your Cook View, Prep View, and Timelines keep working perfectly without any code changes!
        var availableIngredients: [IngredientItem] {
            ingredientCategories.flatMap { $0.items }
        }
    
    // MARK: - Initialization (Loads data when app starts)
    init() {
        loadFromDevice()
    }
    
    // MARK: - App Logic
    func dropIngredients(names: [String]) {
        for itemName in names {
            if let found = availableIngredients.first(where: { $0.name == itemName }), !potIngredients.contains(found) {
                potIngredients.append(found)
            }
        }
    }
    
    func clearPot() {
            potIngredients.removeAll()
            // Clear the array
            suggestedRecipes.removeAll()
        }
    
    func findRecipe() -> Bool {
            let selectedNames = Set(potIngredients.map { $0.name })
            
            // We require an EXACT match:
            let matches = recipeDatabase.filter { $0.requiredIngredients == selectedNames }
            
            if !matches.isEmpty {
                // We found at least one match
                suggestedRecipes = matches
                return true
            } else {
                // No matches found
                suggestedRecipes = []
                return false
            }
        }
    
//    MARK: - Function that finds ingredients belong to which recipe:
    // Checks if adding this specific ingredient will lead to a valid recipe
        func isIngredientValidCombo(_ ingredientName: String) -> Bool {
            // If the pot is empty, they can drag whatever they want
            if potIngredients.isEmpty { return true }
            
            let currentPotNames = Set(potIngredients.map { $0.name })
            
            // We don't need duplicates in the pot
            if currentPotNames.contains(ingredientName) { return false }
            
            // Simulate adding this new ingredient to the pot
            var simulatedPot = currentPotNames
            simulatedPot.insert(ingredientName)
            
            // Does ANY recipe in our database contain this entire combo?
            return recipeDatabase.contains { recipe in
                simulatedPot.isSubset(of: recipe.requiredIngredients)
            }
        }
    
    // MARK: - Database Logic
    func saveCustomRecipe(name: String, emoji: String, method: String, requiredIngredients: Set<String>, before: [String], during: [String], after: [String], preps: [IngredientPrep], phases: [CookPhase], notes: [String], cookTime: Int = 0) {

            // If phases exist, their sum is authoritative. If empty (single-ingredient recipe),
            // use the passed-in cookTime so the timer isn't 0 seconds.
            let totalTime = phases.isEmpty ? cookTime : phases.reduce(0) { $0 + $1.cookTime }
            
            let newRecipe = Recipe(
                name: name,
                requiredIngredients: requiredIngredients,
                method: method,
                emoji: emoji,
                cookTime: totalTime,
                seasoningsBefore: before,
                seasoningsDuring: during,
                seasoningsAfter: after,
                ingredientPreps: preps,
                cookPhases: phases,
                notes: notes
            )
            
            recipeDatabase.append(newRecipe)
            saveToDevice()
        }
    
    // Deletes a recipe and permanently saves the updated list to the device
    func deleteRecipe(at offsets: IndexSet) {
        recipeDatabase.remove(atOffsets: offsets)
        saveToDevice()
    }
    
    // Translates the recipes to JSON and saves them to the iPhone
    private func saveToDevice() {
        if let encoded = try? JSONEncoder().encode(recipeDatabase) {
            UserDefaults.standard.set(encoded, forKey: "SavedRecipes")
        }
    }
    
    // Grabs the JSON from the iPhone and translates it back into Recipes
    private func loadFromDevice() {
        if let savedData = UserDefaults.standard.data(forKey: "SavedRecipes"),
           let decodedRecipes = try? JSONDecoder().decode([Recipe].self, from: savedData) {
            recipeDatabase = decodedRecipes
        }
        else {
            // If it's the user's very first time opening the app, give them the default recipes
            recipeDatabase = defaultRecipes
        }
    }
}
