import AVFoundation

@MainActor
class SoundManager {
    static let shared = SoundManager()
    var player: AVAudioPlayer?
    
    private init() {
        // Wakes up the audio engine:
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default, options: .mixWithOthers)
            try AVAudioSession.sharedInstance().setActive(true)
        } 
        catch {
            print("Failed to set up audio session: \(error)")
        }
    }
    
    func playSound(named eventName: String) {
        var fileName = ""
        
        // Map the events in the app to mp3 files:
        switch eventName {
        case "alarm_zero":
            fileName = "TimerReachedSound"
        case "recipe_created", "cooking_completed", "match_found":
            fileName = "CreationCompleted"
        case "seasoning":
            fileName = "Seasoning"
        case "drop_pot":
            fileName = "DargedIntoCircle"
        case "clear_pot":
            fileName = "EmptyTrash"
        case "chop_hit", "peel":
            fileName = "Slice"
        case "smash":
            fileName = "Smash"
        case "pop", "drag_start":
            AudioServicesPlaySystemSound(1104)
            return
        default:
            return
        }
//        File Loader:
        if let safeURL = Bundle.module.url(forResource: fileName, withExtension: "mp3") {
            do {
                player = try AVAudioPlayer(contentsOf: safeURL)
                player?.prepareToPlay()
                player?.play()
            }
            catch {
                print("AVAudioPlayer Error:", error)
            }
        } else {
            print("Could not find \(fileName).mp3")
        }
        
    }
}
