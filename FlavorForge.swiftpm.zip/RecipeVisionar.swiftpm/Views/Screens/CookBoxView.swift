import SwiftUI

/// MARK Cook Box View
/// I built this main view as the interactive playground where users can drag and drop ingredients into a pot
/// It uses predictive logic to suggest recipes in real time based on what the user is throwing together
struct CookBoxView: View {
    /// I pull in the recipe manager from the environment to access the global ingredient database and pot state
    @EnvironmentObject var manager: RecipeManager
    
    /// I use this boolean to show an alert if the user creates a totally wild ingredient combination
    @State private var showNoMatchAlert = false
    
    /// I trigger this boolean to navigate the user to the final recipe screen when they find a valid match
    @State private var showMatchedRecipes = false
    
    /// MARK Navigation State
    /// I store the currently selected category here so the user can browse specific types of food
    @State private var selectedCategory: IngredientCategory? = nil
    
    /// MARK Custom Drag State
    /// I use this item to track exactly which piece of food the user is currently holding
    @State private var draggingItem: IngredientItem? = nil
    
    /// I use this coordinate point so the ghost emoji can follow the users finger perfectly across the screen
    @State private var dragLocation: CGPoint = .zero
    
    /// I toggle this boolean when the users finger enters the drop zone so I can animate the pot glowing
    @State private var isHoveringPot = false
    
    /// MARK Hint Pop Up State
    /// I store the specific recipe suggestion the user tapped on to display the hint sheet
    @State private var selectedSuggestion: Recipe? = nil
    
    /// MARK Tutorial State
    /// I use app storage here to permanently remember if the user has completed the drag tutorial
    @AppStorage("hasSeenDragTutorial") private var hasSeenDragTutorial = false
    
    /// I use this boolean to animate the tutorial pointing hand
    @State private var bounceHand = false
    
    /// MARK Predictive Logic
    /// I built this computed property to automatically find recipes that contain the items currently in the pot
    var possibleRecipes: [Recipe] {
        guard !manager.potIngredients.isEmpty else { return [] }
        let potNames = Set(manager.potIngredients.map { $0.name })
        
        return manager.recipeDatabase.filter { recipe in
            /// I show the recipe suggestion if the items in the pot are a strict subset of the required ingredients
            potNames.isSubset(of: recipe.requiredIngredients)
        }
    }
    
    /// I build the entire visual interface inside this main body variable
    var body: some View {
        NavigationStack {
            GeometryReader { geo in
                ZStack {
                    /// I use the standard Apple system background color to make it feel native
                    Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                    
                    VStack(spacing: 15) {
                        topBrowserBox(geo: geo)
                        Spacer(minLength: 0)
                        
                        /// I place the floating predictive suggestions bar right here in the middle
                        suggestionsBar
                        
                        potDropZone(geo: geo)
                        Spacer(minLength: 0)
                        actionButtons()
                    }
                    
                    /// I render the ghost emoji overlay right here so it floats above all other views
                    if let draggingItem = draggingItem {
                        Text(draggingItem.emoji)
                            .font(.system(size: 70))
                            .shadow(color: .black.opacity(0.2), radius: 12, y: 8)
                            .position(dragLocation)
                            .ignoresSafeArea()
                    }

                    /// I overlay the tutorial screen if this is the users very first time opening the app
                    if !hasSeenDragTutorial {
                        tutorialOverlay
                            .transition(.opacity)
                            /// I give it a high z index so it completely covers everything else on the screen
                            .zIndex(100)
                    }

                }
            }
            .navigationTitle("Cook")
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(isPresented: $showMatchedRecipes) {
                MatchedRecipesView(recipes: manager.suggestedRecipes)
            }
            .alert("Chef's Surprise!", isPresented: $showNoMatchAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("We don't have a specific recipe for this combo, but it sounds like a creative experiment! Try cooking it!")
            }
            /// I update this to use the modern two parameter closure to keep the compiler happy
            .onChange(of: manager.resetNavigation) { oldValue, newValue in
                if newValue {
                    showMatchedRecipes = false
                    manager.resetNavigation = false
                }
            }
            /// I attach the hint sheet pop up here so it opens when a suggestion is tapped
            .sheet(item: $selectedSuggestion) { recipe in
                RecipeHintSheet(recipe: recipe, potIngredientNames: Set(manager.potIngredients.map { $0.name }))
                    /// I use a native Apple half sheet detent here
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
        }
    }
    
    /// MARK Top Browser Box
    /// I created this box to hold the category list and the individual ingredients
    @ViewBuilder
    private func topBrowserBox(geo: GeometryProxy) -> some View {
        VStack(spacing: 0) {
            Text(selectedCategory == nil ? "Select a Category" : "Hold and Drag Ingredients to the Pot!")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.top, 16)
                .padding(.bottom, 10)
            
            ScrollView(.vertical, showsIndicators: false) {
                Group {
                    if let category = selectedCategory {
                        ingredientGrid(for: category, geo: geo)
                    } else {
                        categoryGrid()
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: selectedCategory == nil)
            }
            .scrollEdgeEffectStyle(.automatic, for: .all)
        }
        /// I explicitly size the height here to leave room for the new suggestions bar below it
        .frame(maxHeight: geo.size.height * 0.52)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .padding(.horizontal, 16)
    }
    
    /// MARK Ingredient Grid
    /// I render this grid of individual food items when the user selects a specific category
    @ViewBuilder
    private func ingredientGrid(for category: IngredientCategory, geo: GeometryProxy) -> some View {
        VStack(alignment: .leading) {
            Button {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                    selectedCategory = nil
                }
            } label: {
                Label("Categories", systemImage: "chevron.backward")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Color.accentColor)
                    .padding(.horizontal)
                    .padding(.bottom, 10)
            }
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 20) {
                ForEach(Array(category.items.enumerated()), id: \.element.id) { index, item in
                    StaggeredAppearView(index: index) {
                        ingredientButton(for: item, geo: geo)
                    }
                }
            }
            .padding(.horizontal)
        }
        .padding(.bottom, 20)
    }
    
    /// MARK Individual Ingredient Button
    /// I built this component to display the draggable food items with smart graying out logic
    @ViewBuilder
    private func ingredientButton(for item: IngredientItem, geo: GeometryProxy) -> some View {
        let isValid = manager.isIngredientValidCombo(item.name)
        let isDraggingThis = draggingItem?.name == item.name
        
        VStack(spacing: 8) {
            Text(item.emoji)
                .font(.system(size: 45))
                .frame(width: 76, height: 76)
                .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 38, style: .continuous))
                .shadow(color: .black.opacity(isValid ? 0.08 : 0.0), radius: isValid ? 8 : 0, y: 4)
                .opacity(isValid ? (isDraggingThis ? 0.3 : 1.0) : 0.3)
                .grayscale(isValid ? 0.0 : 1.0)
                .scaleEffect(isDraggingThis ? 0.9 : 1.0)
                .gesture(
                    isValid ? dragGesture(for: item, geo: geo) : nil
                )
                /// I trigger an error haptic and sound if the user taps an invalid grayed out ingredient
                .onTapGesture {
                    if !isValid {
                        UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                        SoundManager.shared.playSound(named: "drag_invalid")
                    }
                }
            
            Text(item.name)
                .font(.caption2.weight(.medium))
                .lineLimit(1)
                .minimumScaleFactor(0.6)
                .foregroundStyle(isValid ? .primary : .tertiary)
        }
    }
    
    /// I use this complex drag gesture to handle the pickup movement and drop logic
    private func dragGesture(for item: IngredientItem, geo: GeometryProxy) -> some Gesture {
        LongPressGesture(minimumDuration: 0.05)
            .sequenced(before: DragGesture(coordinateSpace: .global))
            .onChanged { value in
                switch value {
                case .second(true, let drag):
                    if let dragValue = drag {
                        if draggingItem?.name != item.name {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            /// I play a tiny pop sound the moment the user successfully picks up an item
                            SoundManager.shared.playSound(named: "drag_start")
                        }
                        draggingItem = item
                        dragLocation = dragValue.location
                        isHoveringPot = dragValue.location.y > (geo.size.height * 0.60)
                    }
                default: break
                }
            }
            .onEnded { _ in
                if isHoveringPot {
                    UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                    /// I play the heavy drop sound right here when the item lands in the pot
                    SoundManager.shared.playSound(named: "drop_pot")
                    
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                        manager.dropIngredients(names: [item.name])
                    }
                }
                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                    draggingItem = nil
                    isHoveringPot = false
                }
            }
    }
    
    /// MARK Category Grid
    /// I render this top level grid to show all available food categories
    @ViewBuilder
    private func categoryGrid() -> some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 24) {
            ForEach(Array(manager.ingredientCategories.enumerated()), id: \.element.id) { index, category in
                StaggeredAppearView(index: index) {
                    categoryButton(for: category)
                }
            }
        }
        .padding(.horizontal)
        .padding(.bottom, 20)
    }
    
    /// I built this button to represent a category and I disable it if no ingredients inside are valid matches
    @ViewBuilder
    private func categoryButton(for category: IngredientCategory) -> some View {
        let isCategoryValid = category.items.contains { manager.isIngredientValidCombo($0.name) }
        let catEmoji = String(category.name.prefix(1))
        let catTitle = String(category.name.dropFirst(2))
        
        Button {
            if isCategoryValid {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                    selectedCategory = category
                }
            }
        } label: {
            VStack(spacing: 8) {
                Text(catEmoji)
                    .font(.system(size: 40))
                    .frame(width: 76, height: 76)
                    .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 38, style: .continuous))
                    .shadow(color: .black.opacity(isCategoryValid ? 0.08 : 0.0), radius: isCategoryValid ? 8 : 0, y: 4)
                    .opacity(isCategoryValid ? 1.0 : 0.3)
                    .grayscale(isCategoryValid ? 0.0 : 1.0)
                
                Text(catTitle)
                    .font(.caption2.weight(.medium))
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.7)
                    .foregroundStyle(isCategoryValid ? .primary : .tertiary)
            }
        }
        .buttonStyle(.plain)
        .disabled(!isCategoryValid)
    }
    
    /// MARK Suggestions Bar
    /// I designed this horizontal scrolling bar to actively predict and suggest recipes as the user cooks
    @ViewBuilder
    private var suggestionsBar: some View {
        let recipes = possibleRecipes
        if !recipes.isEmpty {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(recipes) { recipe in
                        Button {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            /// I play a soft pop sound when the user taps to peek at a suggestion
                            SoundManager.shared.playSound(named: "pop")
                            selectedSuggestion = recipe
                        } label: {
                            HStack(spacing: 6) {
                                Text(recipe.emoji).font(.title3)
                                Text(recipe.name)
                                    .font(.subheadline.weight(.bold))
                                    .foregroundStyle(.primary)
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 16)
                            .glassEffect(.regular, in: Capsule())
                            /// I highlight the capsule with an orange ring to gently draw the users eye
                            .overlay(Capsule().stroke(Color.orange.opacity(0.5), lineWidth: 2))
                            .shadow(color: .black.opacity(0.05), radius: 5, y: 2)
                        }
                        .buttonStyle(.plain)
                        .transition(.scale(scale: 0.8).combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 20)
            }
            .frame(height: 50)
            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: recipes.count)
        } else if !manager.potIngredients.isEmpty {
            /// I show this fallback placeholder text if they have combined things that do not match a recipe yet
            Text("Keep adding ingredients...")
                .font(.subheadline.weight(.medium))
                .foregroundStyle(.tertiary)
                .frame(height: 50)
        }
    }
    
    /// MARK Pot Drop Zone
    /// I built this central area to represent the cooking pot and handle the visual glowing state
    @ViewBuilder
    private func potDropZone(geo: GeometryProxy) -> some View {
        ZStack {
            Circle()
                .fill(isHoveringPot ? Color.green.opacity(0.2) : Color.clear)
                .glassEffect(.regular, in: Circle())
                .frame(width: 170, height: 170)
                .overlay(
                    Circle().stroke(
                        isHoveringPot ? Color.green : Color.orange.opacity(0.5),
                        style: StrokeStyle(lineWidth: isHoveringPot ? 4 : 2, dash: [8])
                    )
                )
                .scaleEffect(isHoveringPot ? 1.05 : 1.0)
                .animation(.spring(response: 0.3, dampingFraction: 0.6), value: isHoveringPot)
            
            if manager.potIngredients.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "arrow.down.circle")
                        .font(.system(size: 30, weight: .light))
                    Text("Drop Here")
                        .font(.headline)
                }
                .foregroundStyle(.tertiary)
            } else {
                ForEach(Array(manager.potIngredients.enumerated()), id: \.offset) { index, item in
                    Text(item.emoji)
                        .font(.system(size: 42))
                        .offset(x: cos(Double(index) / Double(manager.potIngredients.count) * 2 * .pi) * 40,
                                y: sin(Double(index) / Double(manager.potIngredients.count) * 2 * .pi) * 40)
                        .transition(.scale.combined(with: .opacity))
                }
            }
        }
        .padding(.vertical, 5)
    }
    
    /// MARK Tutorial Overlay
    /// I created this dark overlay to guide brand new users before they start exploring
    @ViewBuilder
    private var tutorialOverlay: some View {
        ZStack {
            /// I darken the background heavily so the user focuses entirely on the welcome message
            Color.black.opacity(0.6).ignoresSafeArea()
            
            VStack(spacing: 24) {
                Spacer()
                
                VStack(spacing: 16) {
                    Text("Welcome, Chef! 🧑‍🍳")
                        .font(.largeTitle.weight(.bold))
                        .foregroundStyle(.white)
                    
                    Text("Hold and drag ingredients from the menu\ndown into the pot to discover recipes.")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.9))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                }
                
                Spacer()
                
                Button {
                    UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                    SoundManager.shared.playSound(named: "pop")
                    withAnimation(.easeOut(duration: 0.3)) {
                        hasSeenDragTutorial = true
                    }
                } label: {
                    Text("Let's Cook!")
                        .font(.title3.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.orange, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .padding(.horizontal, 40)
                .padding(.bottom, 60)
            }
        }
        /// I keep hit testing completely active so the user is forced to tap the button to proceed
        .allowsHitTesting(true)
    }
    
    /// MARK Action Buttons
    /// I built these bottom buttons so the user can wipe the board clean or confirm their recipe match
    @ViewBuilder
    private func actionButtons() -> some View {
        HStack(spacing: 16) {
            Button(role: .destructive) {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                /// I play the trash sound effect to give satisfying audio feedback when emptying the pot
                SoundManager.shared.playSound(named: "clear_pot")
                
                withAnimation { manager.clearPot() }
            }
            label: {
                Label("Clear Pot", systemImage: "trash")
                    .font(.headline)
                    .frame(width: 50, height: 50)
            }
            .labelStyle(.iconOnly)
            .buttonStyle(.glass)
            .tint(.red)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .disabled(manager.potIngredients.isEmpty)
            
            Button {
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                if manager.findRecipe() {
                    SoundManager.shared.playSound(named: "match_found")
                    showMatchedRecipes = true
                } else {
                    showNoMatchAlert = true
                }
            } label: {
                Text("What can I make?")
                    .font(.headline.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
            .controlSize(.extraLarge)
            .buttonStyle(.glassProminent)
            .tint(.orange)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .disabled(manager.potIngredients.isEmpty)
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 20)
    }
}

/// MARK The Magic Animation Wrapper
/// I built this wrapper to guarantee a perfect staggered entrance by isolating the animation timeline
/// from its parent view
struct StaggeredAppearView<Content: View>: View {
    let index: Int
    @ViewBuilder let content: () -> Content
    
    @State private var isVisible = false
    
    var body: some View {
        content()
            .opacity(isVisible ? 1 : 0.001)
            .scaleEffect(isVisible ? 1 : 0.5)
            .onAppear {
                /// I multiply the index by a fraction of a second to create the fluid popping cascade
                withAnimation(.spring(response: 0.5, dampingFraction: 0.7).delay(Double(index) * 0.03)) {
                    isVisible = true
                }
            }
            .onDisappear {
                /// I immediately reset this back to false when navigating away so it animates fresh next time
                isVisible = false
            }
    }
}


/// MARK The Recipe Hint Checklist
/// I created this sheet view to act as a dynamic shopping list that actively tracks what is already in the pot
struct RecipeHintSheet: View {
    @EnvironmentObject var manager: RecipeManager
    @Environment(\.dismiss) var dismiss
    
    let recipe: Recipe
    let potIngredientNames: Set<String>
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        /// I highlight the hero dish right at the top so the user knows what they are building
                        Text(recipe.emoji)
                            .font(.system(size: 80))
                            .shadow(color: .black.opacity(0.15), radius: 10, y: 5)
                            .padding(.top, 20)
                        
                        VStack(spacing: 12) {
                            /// I sort the list dynamically so the ingredients you ALREADY have naturally float to the top
                            let sortedIngredients = Array(recipe.requiredIngredients).sorted {
                                let hasFirst = potIngredientNames.contains($0)
                                let hasSecond = potIngredientNames.contains($1)
                                if hasFirst == hasSecond { return $0 < $1 }
                                return hasFirst && !hasSecond
                            }
                            
                            ForEach(sortedIngredients, id: \.self) { ingredientName in
                                let hasIngredient = potIngredientNames.contains(ingredientName)
                                let emoji = manager.availableIngredients.first(where: { $0.name == ingredientName })?.emoji ?? "🥘"
                                
                                HStack(spacing: 16) {
                                    Text(emoji)
                                        .font(.title2)
                                        /// I physically gray out the missing ingredients so the user immediately sees what is left
                                        .grayscale(hasIngredient ? 0.0 : 1.0)
                                        .opacity(hasIngredient ? 1.0 : 0.4)
                                    
                                    Text(ingredientName)
                                        .font(.headline.weight(hasIngredient ? .bold : .medium))
                                        .foregroundStyle(hasIngredient ? .primary : .secondary)
                                        /// I strike a line through the text once it is successfully dropped in the pot
                                        .strikethrough(hasIngredient, color: .secondary)
                                    
                                    Spacer()
                                    
                                    /// I render standard visual checkmarks here to create a satisfying checklist feel
                                    if hasIngredient {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundStyle(.green)
                                            .font(.title2)
                                    } else {
                                        Image(systemName: "circle.dashed")
                                            .foregroundStyle(.orange)
                                            .font(.title2)
                                    }
                                }
                                .padding()
                                .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("Recipe Hint")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Got it") { dismiss() }
                        .font(.headline)
                        .foregroundStyle(.orange)
                }
            }
        }
    }
}
