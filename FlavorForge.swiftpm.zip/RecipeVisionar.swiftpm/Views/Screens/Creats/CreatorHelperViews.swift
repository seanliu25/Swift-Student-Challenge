import SwiftUI

/// I created this file to hold all my small helper views and extensions
/// This keeps my main files very clean and easy for you to read
/// You will find my extensions and custom design elements here

extension View {
    /// I use this handy trick to dismiss the keyboard from anywhere in my app
    /// You just call hideKeyboard and the system forces the keyboard down
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

extension View {
    /// I built this advanced spotlight cutout tool
    /// It lets me punch a hole in a view so you can see what is underneath
    func reverseMask<Mask: View>(
        alignment: Alignment = .center,
        @ViewBuilder _ mask: () -> Mask
    ) -> some View {
        self.mask {
            Rectangle()
                .overlay(alignment: alignment) {
                    mask()
                        .blendMode(.destinationOut)
                }
        }
    }
}

/// I use this view to show a beautiful row in the final review step
/// It takes an icon and text and makes it look like a native Apple settings menu
struct ReviewRow: View {
    let icon: String
    let title: String
    let text: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon).foregroundStyle(Color.orange).frame(width: 24)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.caption.weight(.bold)).foregroundStyle(.secondary).textCase(.uppercase)
                Text(text).font(.subheadline.weight(.medium)).foregroundStyle(.primary)
            }
        }
    }
}

/// I designed this drop zone so you can easily toss your spices into it
/// I bound the items array so it updates the main list automatically
struct SeasoningDropZone: View {
    let title: String
    @Binding var items: [String]
    var isHovered: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            Text(title).font(.caption.weight(.bold)).foregroundStyle(.secondary).textCase(.uppercase).padding(.top, 12).padding(.bottom, 8)
            ScrollView {
                VStack(spacing: 8) {
                    ForEach(items, id: \.self) { item in
                        Button {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { items.removeAll(where: { $0 == item }) }
                        } label: {
                            HStack(spacing: 4) {
                                Text(item).lineLimit(1).minimumScaleFactor(0.5)
                                Image(systemName: "xmark.circle.fill").foregroundStyle(Color.red.opacity(0.8))
                            }
                            .font(.caption2.weight(.semibold))
                            .padding(.vertical, 8)
                            .padding(.horizontal, 10)
                            .background(Capsule(style: .continuous).fill(Color.orange.opacity(0.15)))
                            .foregroundStyle(.primary)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.bottom, 10).padding(.horizontal, 8)
            }
        }
        .frame(height: 160)
        .frame(maxWidth: .infinity)
        .background(isHovered ? .ultraThinMaterial : .regularMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(isHovered ? Color.green : Color.clear, lineWidth: 3))
        .scaleEffect(isHovered ? 1.05 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: isHovered)
    }
}

/// This is my sheet that lets you pick a custom avatar for your dish
/// I curated a list of emojis that look like cooked meals
struct RecipeIconPickerSheet: View {
    @Binding var selectedEmoji: String
    @Environment(\.dismiss) var dismiss
    
    let foodOptions = [
        "🍲", "🥗", "🥘", "🍝", "🍜", "🍛", "🍣", "🍱",
        "🥟", "🍔", "🍕", "🌮", "🌯", "🥩", "🍗", "🥪",
        "🍳", "🥞", "🍰", "🥧", "🥣", "🥙", "🍖", "🍤"
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                
                ScrollView {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 70), spacing: 20)], spacing: 20) {
                        ForEach(foodOptions, id: \.self) { emoji in
                            Button {
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                                    selectedEmoji = emoji
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                    dismiss()
                                }
                            } label: {
                                Text(emoji)
                                    .font(.system(size: 40))
                                    .frame(width: 70, height: 70)
                                    .glassEffect(.regular, in: Circle())
                                    .overlay(
                                        Circle().stroke(selectedEmoji == emoji ? Color.orange : Color.clear, lineWidth: 3)
                                    )
                                    .scaleEffect(selectedEmoji == emoji ? 1.15 : 1.0)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(20)
                }
            }
            .navigationTitle("Choose Dish Icon")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .font(.headline)
                        .foregroundStyle(Color.orange)
                }
            }
        }
    }
}
