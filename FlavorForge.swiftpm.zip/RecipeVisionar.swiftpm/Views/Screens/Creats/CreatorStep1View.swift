import SwiftUI

/// I made this view to handle the very first step of my recipe wizard
/// It uses bindings so it can update the memory in the main file
struct CreatorStep1View: View {
    @Binding var customEmoji: String
    @Binding var showEmojiPicker: Bool
    @Binding var customName: String
    @Binding var selectedMethod: String
    
    let methods: [String: String]
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Step 1: The Basics").font(.title.weight(.bold))
            
            /// Here I am creating the profile photo button
            /// Tapping this tells the main view to show the sheet
            Button {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                showEmojiPicker = true
            } label: {
                ZStack(alignment: .bottomTrailing) {
                    Text(customEmoji)
                        .font(.system(size: 60))
                        .frame(width: 110, height: 110)
                        .glassEffect(.regular, in: Circle())
                        .shadow(color: .black.opacity(0.1), radius: 10, y: 5)
                    
                    Image(systemName: "pencil.circle.fill")
                        .font(.title)
                        .foregroundStyle(.white, .orange)
                        .background(Circle().fill(Color(uiColor: .systemGroupedBackground)))
                        .offset(x: 5, y: 5)
                }
            }
            .buttonStyle(.plain)
            
            TextField("Name your masterpiece...", text: $customName)
                .padding()
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .padding(.horizontal)
                .submitLabel(.done)
                .onSubmit { hideKeyboard() }
            
            VStack(spacing: 12) {
                Text("How will you cook it?").font(.headline).foregroundStyle(.secondary)
                
                Picker("Cooking Method", selection: $selectedMethod) {
                    ForEach(methods.keys.sorted(), id: \.self) { method in
                        Text("\(methods[method] ?? "🍳") \(method)").tag(method)
                    }
                }
                .pickerStyle(.menu)
                .controlSize(.extraLarge)
                .buttonStyle(.glass)
                .tint(.orange)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                
                Text(methods[selectedMethod] ?? "🍳")
                    .font(.system(size: 80))
                    .padding(.top, 20)
                    .transition(.scale.combined(with: .opacity))
                    .id(selectedMethod)
            }
        }
    }
}
