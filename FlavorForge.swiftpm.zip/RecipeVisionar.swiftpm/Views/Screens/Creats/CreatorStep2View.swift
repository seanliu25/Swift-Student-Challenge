import SwiftUI

/// I built this view to let the user browse ingredients
/// I pass the geometry proxy so my grid knows how tall the screen is
struct CreatorStep2View: View {
    @EnvironmentObject var manager: RecipeManager
    
    @Binding var selectedCategory: IngredientCategory?
    @Binding var selectedIngredients: Set<String>
    @Binding var cookPhases: [CookPhase]
    @Binding var stagedIngredients: [String]
    
    let geo: GeometryProxy
    
    var body: some View {
        VStack(spacing: 15) {
            Text("Step 2: Ingredients").font(.title.weight(.bold))
            Text(selectedCategory == nil ? "Tap a category to open it!" : "Tap to add to your recipe!")
                .font(.subheadline).foregroundStyle(.secondary)
            
            ScrollView(.vertical, showsIndicators: false) {
                Group {
                    if let category = selectedCategory {
                        ingredientGrid(for: category)
                    } else {
                        categoryGrid()
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: selectedCategory == nil)
            }
            .scrollEdgeEffectStyle(.automatic, for: .all)
            .frame(maxHeight: geo.size.height * 0.65)
            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .padding(.horizontal, 16)
            
            Text("\(selectedIngredients.count) items selected")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(selectedIngredients.isEmpty ? Color.secondary : Color.green)
        }
    }
    
    /// This shows the folders for the different food groups
    @ViewBuilder
    private func categoryGrid() -> some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 24) {
            ForEach(Array(manager.ingredientCategories.enumerated()), id: \.element.id) { index, category in
                StaggeredAppearView(index: index) {
                    let catEmoji = String(category.name.prefix(1))
                    let catTitle = String(category.name.dropFirst(2))
                    let selectedCount = category.items.filter { selectedIngredients.contains($0.name) }.count
                    
                    Button {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { selectedCategory = category }
                    } label: {
                        VStack(spacing: 8) {
                            ZStack(alignment: .topTrailing) {
                                Text(catEmoji)
                                    .font(.system(size: 40))
                                    .frame(width: 76, height: 76)
                                    .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 38, style: .continuous))
                                    .shadow(color: .black.opacity(0.04), radius: 8, y: 4)
                                
                                if selectedCount > 0 {
                                    Text("\(selectedCount)")
                                        .font(.caption2.weight(.bold))
                                        .foregroundStyle(.white)
                                        .frame(width: 24, height: 24)
                                        .background(Circle().fill(Color.green))
                                        .offset(x: 4, y: -4)
                                }
                            }
                            Text(catTitle)
                                .font(.caption2.weight(.medium))
                                .multilineTextAlignment(.center)
                                .lineLimit(2)
                                .minimumScaleFactor(0.7)
                                .foregroundStyle(.primary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 15)
    }
    
    /// This shows the actual food items inside the folder you tapped
    @ViewBuilder
    private func ingredientGrid(for category: IngredientCategory) -> some View {
        VStack(alignment: .leading) {
            Button {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                SoundManager.shared.playSound(named: "pop")
                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { selectedCategory = nil }
            } label: {
                Label("Categories", systemImage: "chevron.backward")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Color.accentColor)
            }
            .padding(.horizontal).padding(.bottom, 10)
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 20) {
                ForEach(Array(category.items.enumerated()), id: \.element.id) { index, item in
                    StaggeredAppearView(index: index) {
                        let isSelected = selectedIngredients.contains(item.name)
                        
                        Button {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            SoundManager.shared.playSound(named: "pop")
                            
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                if isSelected {
                                    selectedIngredients.remove(item.name)
                                    for i in cookPhases.indices.reversed() {
                                        cookPhases[i].ingredients.removeAll(where: { $0 == item.name })
                                        if cookPhases[i].ingredients.isEmpty { cookPhases.remove(at: i) }
                                    }
                                    stagedIngredients.removeAll(where: { $0 == item.name })
                                } else {
                                    selectedIngredients.insert(item.name)
                                }
                            }
                        } label: {
                            VStack(spacing: 8) {
                                Text(item.emoji)
                                    .font(.system(size: 45))
                                    .frame(width: 76, height: 76)
                                    .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 38, style: .continuous))
                                    .overlay(RoundedRectangle(cornerRadius: 38, style: .continuous).stroke(isSelected ? Color.green : Color.clear, lineWidth: 3))
                                    .scaleEffect(isSelected ? 1.05 : 1.0)
                                
                                Text(item.name)
                                    .font(.caption2.weight(.medium))
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.6)
                                    .foregroundStyle(isSelected ? Color.green : Color.primary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .padding(.vertical, 15)
    }
}
