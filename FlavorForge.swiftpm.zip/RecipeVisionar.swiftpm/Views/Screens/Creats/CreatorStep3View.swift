import SwiftUI

/// I built this so you can decide exactly how each food is cut or smashed
/// It reads the items you selected in step two and shows options for them
struct CreatorStep3View: View {
    @Binding var selectedIngredients: Set<String>
    @Binding var itemCutStyles: [String: String]
    @Binding var itemPreSeasoning: [String: Bool]
    
    let cutStyles: [String]
    
    var body: some View {
        VStack(spacing: 15) {
            Text("Step 3: Prep Details").font(.title.weight(.bold))
            Text("Customize each ingredient!").font(.subheadline).foregroundStyle(.secondary)
            
            if selectedIngredients.isEmpty {
                Spacer()
                Text("Go back and select ingredients first!").foregroundStyle(.tertiary)
                Spacer()
            } else {
                ScrollView {
                    VStack(spacing: 20) {
                        ForEach(Array(selectedIngredients).sorted(), id: \.self) { ingredient in
                            VStack(alignment: .leading, spacing: 16) {
                                Text(ingredient).font(.title3.weight(.bold))
                                
                                LazyVGrid(columns: [GridItem(.adaptive(minimum: 80), spacing: 10)], spacing: 12) {
                                    ForEach(cutStyles, id: \.self) { style in
                                        let isSelected = (itemCutStyles[ingredient] ?? "None") == style
                                        Text(style)
                                            .font(.subheadline.weight(.medium))
                                            .padding(.vertical, 10)
                                            .frame(maxWidth: .infinity)
                                            .background(
                                                Capsule(style: .continuous)
                                                    .fill(isSelected ? Color.orange.opacity(0.15) : Color(uiColor: .tertiarySystemGroupedBackground))
                                            )
                                            .overlay(Capsule(style: .continuous).stroke(isSelected ? Color.orange : Color.clear, lineWidth: 2))
                                            .foregroundStyle(isSelected ? Color.orange : Color.primary)
                                            .onTapGesture {
                                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                                withAnimation { itemCutStyles[ingredient] = style }
                                            }
                                    }
                                }
                                
                                Toggle("Needs Pre seasoning? 🧂", isOn: Binding(
                                    get: { itemPreSeasoning[ingredient] ?? false },
                                    set: { itemPreSeasoning[ingredient] = $0 }
                                ))
                                .font(.subheadline.weight(.medium))
                                .tint(.orange)
                            }
                            .padding()
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
            }
        }
    }
}
