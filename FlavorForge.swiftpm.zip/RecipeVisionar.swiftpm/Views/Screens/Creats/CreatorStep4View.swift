import SwiftUI

/// I built this so users can leave special instructions for themselves
/// It holds an array of simple text notes that display at the end
struct CreatorStep4View: View {
    @Binding var customNotes: [String]
    @Binding var newNoteText: String
    
    var body: some View {
        VStack(spacing: 15) {
            Text("Step 4: Chef's Notes").font(.title.weight(.bold))
            Text("Add techniques, tips, or warnings!").font(.subheadline).foregroundStyle(.secondary)
            
            HStack {
                TextField("E.g., Oven Temperature: 400°F...", text: $newNoteText)
                    .padding()
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .submitLabel(.done)
                    .onSubmit { addCustomNote() }
                
                Button(action: addCustomNote) {
                    Image(systemName: "plus")
                        .font(.headline)
                        .padding()
                        .background(Color.orange, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .foregroundStyle(.white)
                }
            }
            .padding(.horizontal)
            
            if customNotes.isEmpty {
                Spacer()
                Text("No notes added yet. These are optional!").foregroundStyle(.tertiary)
                Spacer()
            } else {
                List {
                    Section {
                        ForEach(customNotes, id: \.self) { note in
                            Text(note).font(.body)
                        }
                        .onDelete { offsets in
                            customNotes.remove(atOffsets: offsets)
                        }
                    } header: {
                        Text("Recipe Notes").font(.subheadline)
                    }
                }
                .scrollContentBackground(.hidden)
                .scrollDismissesKeyboard(.interactively)
            }
        }
    }
    
    /// I use this function to append the typed text to the array
    private func addCustomNote() {
        if !newNoteText.isEmpty {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            withAnimation { customNotes.append(newNoteText) }
            newNoteText = ""
        }
        hideKeyboard()
    }
}
