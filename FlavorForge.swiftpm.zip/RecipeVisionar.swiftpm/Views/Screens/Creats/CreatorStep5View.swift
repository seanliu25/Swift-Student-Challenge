import SwiftUI

/// This is where the magic happens for planning the timeline
/// I use geometry readers and drag gestures to detect what goes in the pot
struct CreatorStep5View: View {
    @EnvironmentObject var manager: RecipeManager
    
    @Binding var selectedIngredients: Set<String>
    @Binding var cookPhases: [CookPhase]
    @Binding var stagedIngredients: [String]
    @Binding var phaseTime: Double
    @Binding var timelineDraggingItem: String?
    @Binding var isHoveringTimelinePot: Bool
    
    /// I added this line so the view knows where your finger is
    @Binding var dragLocation: CGPoint
    
    let geo: GeometryProxy
    
    var body: some View {
        VStack(spacing: 15) {
            Text("Step 5: Cooking Order").font(.title.weight(.bold))
            
            let unassigned = selectedIngredients.filter { item in
                !cookPhases.contains(where: { $0.ingredients.contains(item) }) && !stagedIngredients.contains(item)
            }.sorted()
            
            if !cookPhases.isEmpty {
                Text("Tap a scheduled batch to undo!").font(.caption).foregroundStyle(.secondary)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(cookPhases) { phase in
                            HStack(spacing: 10) {
                                HStack(spacing: -8) {
                                    ForEach(phase.ingredients, id: \.self) { ing in
                                        Text(manager.availableIngredients.first(where: { $0.name == ing })?.emoji ?? "🍲")
                                            .font(.title3)
                                            .background(Circle().fill(Color(uiColor: .secondarySystemGroupedBackground)).shadow(radius: 2))
                                    }
                                }
                                Text(phase.cookTime == 0 ? "N/A" : "\(phase.cookTime)m")
                                    .font(.subheadline.weight(.bold))
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 14)
                            .background(Capsule(style: .continuous).fill(Color.orange.opacity(0.15)))
                            .onTapGesture {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                    cookPhases.removeAll(where: { $0.id == phase.id })
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .frame(height: 60)
            } else {
                Text("Drag ingredients to the pot, set time, and confirm!").font(.caption).foregroundStyle(.secondary)
            }
            
            if unassigned.isEmpty && stagedIngredients.isEmpty {
                Spacer()
                Text("All ingredients scheduled! ✅").font(.title2.weight(.bold)).foregroundStyle(Color.green)
                Button("Reset Timeline") {
                    withAnimation { cookPhases.removeAll(); stagedIngredients.removeAll(); phaseTime = 5.0 }
                }
                .buttonStyle(.bordered)
                .tint(.red)
                .clipShape(Capsule(style: .continuous))
                .padding(.top, 10)
                Spacer()
            } else {
                ZStack {
                    Circle()
                        .fill(isHoveringTimelinePot ? Color.green.opacity(0.2) : Color.clear)
                        .glassEffect(.regular, in: Circle())
                        .frame(width: 170, height: 170)
                        .overlay(Circle().stroke(isHoveringTimelinePot ? Color.green : Color.orange.opacity(0.5), style: StrokeStyle(lineWidth: isHoveringTimelinePot ? 4 : 2, dash: [8])))
                        .scaleEffect(isHoveringTimelinePot ? 1.05 : 1.0)
                        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: isHoveringTimelinePot)
                    
                    if stagedIngredients.isEmpty {
                        VStack(spacing: 8) {
                            Image(systemName: "arrow.down.circle").font(.title)
                            Text("Drop Here").font(.subheadline.weight(.medium))
                        }
                        .foregroundStyle(.tertiary)
                    } else {
                        VStack {
                            HStack(spacing: -12) {
                                ForEach(stagedIngredients, id: \.self) { item in
                                    Text(manager.availableIngredients.first(where: { $0.name == item })?.emoji ?? "")
                                        .font(.system(size: 45)).shadow(color: .black.opacity(0.1), radius: 5, y: 3)
                                }
                            }
                            Text("Tap to Undo").font(.caption2.weight(.medium)).foregroundStyle(.secondary).padding(.top, 8)
                        }
                        .onTapGesture {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) { stagedIngredients.removeAll() }
                        }
                    }
                }
                .coordinateSpace(name: "timelinePot")
                .padding(.vertical, 15)
                
                if !stagedIngredients.isEmpty {
                    VStack(spacing: 15) {
                        Text(phaseTime == 0 ? "No Timer (Just Drop In)" : "\(Int(phaseTime)) Minutes")
                            .font(.headline)
                            .foregroundStyle(phaseTime == 0 ? Color.secondary : Color.orange)
                        
                        Slider(value: $phaseTime, in: 0...120, step: 1) {
                            Text("Time")
                        } minimumValueLabel: {
                            Text("0m").font(.caption2.weight(.bold)).foregroundStyle(.secondary)
                        } maximumValueLabel: {
                            Text("120m").font(.caption2.weight(.bold)).foregroundStyle(.secondary)
                        }
                        .tint(.orange)
                        .padding(.horizontal, 40)
                        
                        Button {
                            UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                cookPhases.append(CookPhase(ingredients: stagedIngredients, cookTime: Int(phaseTime)))
                                stagedIngredients.removeAll()
                                phaseTime = 5.0
                            }
                        } label: {
                            Text("Confirm Batch!")
                                .font(.headline.weight(.semibold))
                                .frame(minWidth: 150)
                                .padding(.vertical, 12)
                        }
                        .buttonStyle(.glassProminent)
                        .tint(.green)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                } else {
                    Text("Drag an ingredient into the pot!").foregroundStyle(.orange).frame(height: 120)
                }
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(unassigned, id: \.self) { itemName in
                            let emoji = manager.availableIngredients.first(where: { $0.name == itemName })?.emoji ?? "🍲"
                            VStack(spacing: 8) {
                                Text(emoji)
                                    .font(.system(size: 40))
                                    .frame(width: 70, height: 70)
                                    .glassEffect(.regular, in: Circle())
                                    .opacity(timelineDraggingItem == itemName ? 0.3 : 1.0)
                                    .scaleEffect(timelineDraggingItem == itemName ? 0.9 : 1.0)
                                    .gesture(
                                        LongPressGesture(minimumDuration: 0.05)
                                            .sequenced(before: DragGesture(coordinateSpace: .global))
                                            .onChanged { value in
                                                switch value {
                                                case .second(true, let drag):
                                                    if let dragValue = drag {
                                                        if timelineDraggingItem != itemName { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
                                                        timelineDraggingItem = itemName
//                                                        I added this line to make the ghost emoji follow your finger
                                                        dragLocation = dragValue.location
                                                        let midY = geo.size.height * 0.5
                                                        isHoveringTimelinePot = abs(dragValue.location.y - midY) < 110
                                                    }
                                                default: break
                                                }
                                            }
                                            .onEnded { _ in
                                                if isHoveringTimelinePot {
                                                    UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                                                    withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) { stagedIngredients.append(itemName) }
                                                }
                                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                                    timelineDraggingItem = nil
                                                    isHoveringTimelinePot = false
                                                }
                                            }
                                    )
                                Text(itemName).font(.caption2.weight(.medium)).foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 10)
                }
                .frame(height: 110)
            }
        }
    }
}
