import SwiftUI

/// I built this to let users drag seasonings into specific time slots
/// It divides the screen into thirds to know where you drop the flavor
struct CreatorStep6View: View {
    @Binding var customSeasoningText: String
    @Binding var availableSeasonings: [String]
    @Binding var seasoningsBefore: [String]
    @Binding var seasoningsDuring: [String]
    @Binding var seasoningsAfter: [String]
    
    @Binding var draggingSeasoning: String?
    @Binding var dragLocation: CGPoint
    @Binding var hoveredZone: String?
    
    let geo: GeometryProxy
    
    var body: some View {
        VStack(spacing: 15) {
            Text("Step 6: Flavor Stages").font(.title.weight(.bold))
            Text("Drag seasonings into the boxes!").font(.subheadline).foregroundStyle(.secondary)
            
            HStack {
                TextField("Custom sauce or spice...", text: $customSeasoningText)
                    .padding()
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .submitLabel(.done)
                    .onSubmit { addCustomSeasoning() }
                
                Button(action: addCustomSeasoning) {
                    Image(systemName: "plus")
                        .font(.headline)
                        .padding()
                        .background(Color.orange, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .foregroundStyle(.white)
                }
            }
            .padding(.horizontal)
            
            ScrollView(.vertical, showsIndicators: false) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 110), spacing: 15)], spacing: 15) {
                    ForEach(availableSeasonings, id: \.self) { seasoning in
                        Text(seasoning)
                            .font(.subheadline.weight(.semibold))
                            .padding(.vertical, 12)
                            .frame(maxWidth: .infinity)
                            .glassEffect(.regular, in: Capsule(style: .continuous))
                            .opacity(draggingSeasoning == seasoning ? 0.3 : 1.0)
                            .scaleEffect(draggingSeasoning == seasoning ? 0.95 : 1.0)
                            .gesture(
                                LongPressGesture(minimumDuration: 0.15)
                                    .sequenced(before: DragGesture(coordinateSpace: .global))
                                    .onChanged { value in
                                        switch value {
                                        case .second(true, let drag):
                                            if let dragValue = drag {
                                                if draggingSeasoning != seasoning { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                                                draggingSeasoning = seasoning
                                                dragLocation = dragValue.location
                                                
                                                let dropZoneThreshold = geo.size.height * 0.65
                                                if dragValue.location.y > dropZoneThreshold {
                                                    let third = geo.size.width / 3
                                                    if dragValue.location.x < third { hoveredZone = "Before" }
                                                    else if dragValue.location.x < (third * 2) { hoveredZone = "During" }
                                                    else { hoveredZone = "After" }
                                                } else { hoveredZone = nil }
                                            }
                                        default: break
                                        }
                                    }
                                    .onEnded { _ in
                                        if let zone = hoveredZone {
                                            UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                                            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                                if zone == "Before" && !seasoningsBefore.contains(seasoning) { seasoningsBefore.append(seasoning) }
                                                else if zone == "During" && !seasoningsDuring.contains(seasoning) { seasoningsDuring.append(seasoning) }
                                                else if zone == "After" && !seasoningsAfter.contains(seasoning) { seasoningsAfter.append(seasoning) }
                                            }
                                        }
                                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                            draggingSeasoning = nil
                                            hoveredZone = nil
                                        }
                                    }
                            )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 15)
            }
            .frame(maxHeight: geo.size.height * 0.35)
            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .padding(.horizontal)
            .scrollDismissesKeyboard(.interactively)
            
            Spacer()
            
            HStack(spacing: 12) {
                SeasoningDropZone(title: "Before", items: $seasoningsBefore, isHovered: hoveredZone == "Before")
                SeasoningDropZone(title: "During", items: $seasoningsDuring, isHovered: hoveredZone == "During")
                SeasoningDropZone(title: "After",  items: $seasoningsAfter,  isHovered: hoveredZone == "After")
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
        }
    }
    
    /// I use this to inject the typed spice right into the top of the array
    private func addCustomSeasoning() {
        if !customSeasoningText.isEmpty {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            withAnimation { availableSeasonings.insert(customSeasoningText, at: 0) }
            customSeasoningText = ""
        }
        hideKeyboard()
    }
}
