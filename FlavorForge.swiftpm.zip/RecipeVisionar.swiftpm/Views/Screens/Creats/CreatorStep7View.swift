import SwiftUI

/// I use this view as the final checkout cart where users review what they built
/// When they press save it packages everything up into a brand new recipe
struct CreatorStep7View: View {
    @EnvironmentObject var manager: RecipeManager
    
    @Binding var customName: String
    @Binding var customEmoji: String
    @Binding var selectedMethod: String
    @Binding var selectedIngredients: Set<String>
    
    @Binding var seasoningsBefore: [String]
    @Binding var seasoningsDuring: [String]
    @Binding var seasoningsAfter: [String]
    
    @Binding var itemCutStyles: [String: String]
    @Binding var itemPreSeasoning: [String: Bool]
    @Binding var cookPhases: [CookPhase]
    @Binding var customNotes: [String]
    @Binding var phaseTime: Double
    
    @Binding var showSavedAlert: Bool
    let methods: [String: String]
    
    var body: some View {
        VStack(spacing: 24) {
            Text("Ready to Cook! 🎉").font(.largeTitle.weight(.bold))
            
            VStack(alignment: .leading, spacing: 16) {
                ReviewRow(icon: "doc.text.fill", title: "Recipe", text: customName.isEmpty ? "My Custom Dish" : customName)
                ReviewRow(icon: "flame.fill", title: "Method", text: "\(selectedMethod) \(methods[selectedMethod] ?? "")")
                ReviewRow(icon: "basket.fill", title: "Ingredients", text: selectedIngredients.isEmpty ? "None!" : selectedIngredients.joined(separator: ", "))
                if !seasoningsBefore.isEmpty { ReviewRow(icon: "sparkles", title: "Before", text: seasoningsBefore.joined(separator: ", ")) }
                if !seasoningsDuring.isEmpty { ReviewRow(icon: "sparkles", title: "During", text: seasoningsDuring.joined(separator: ", ")) }
                if !seasoningsAfter.isEmpty { ReviewRow(icon: "sparkles", title: "After", text: seasoningsAfter.joined(separator: ", ")) }
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .padding(.horizontal)
            
            Spacer()
            
            Button {
                UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
                SoundManager.shared.playSound(named: "recipe_created")
                
                let packagedPreps = selectedIngredients.map { name in
                    let finalCutStyle = (itemCutStyles[name] ?? "None").isEmpty ? "None" : (itemCutStyles[name] ?? "None")
                    return IngredientPrep(name: name, cutStyle: finalCutStyle, preSeason: itemPreSeasoning[name] ?? false)
                }
                
                let totalCookTime = cookPhases.isEmpty ? Int(phaseTime) : cookPhases.reduce(0) { $0 + $1.cookTime }
                
                manager.saveCustomRecipe(
                    name: customName.isEmpty ? "My Custom Dish" : customName,
                    emoji: customEmoji,
                    method: selectedMethod,
                    requiredIngredients: selectedIngredients,
                    before: seasoningsBefore,
                    during: seasoningsDuring,
                    after: seasoningsAfter,
                    preps: packagedPreps,
                    phases: cookPhases,
                    notes: customNotes,
                    cookTime: totalCookTime
                )
                showSavedAlert = true
            } label: {
                Text("Save and Cook!")
                    .font(.title3.weight(.bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
            }
            .controlSize(.extraLarge)
            .buttonStyle(.glassProminent)
            .tint(.orange)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.horizontal)
            .padding(.bottom, 30)
        }
    }
}
