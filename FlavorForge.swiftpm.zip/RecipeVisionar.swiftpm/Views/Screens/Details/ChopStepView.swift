import SwiftUI

/// MARK Interactive Chop View
/// I built this interactive view so the user can chop slice and smash their food
/// It makes the app feel like a game instead of just a standard recipe list
struct ChopStepView: View {
    
    /// I grab the manager to find the emojis for my ingredients
    @EnvironmentObject var manager: RecipeManager
    
    /// I store the current recipe to read the custom cut styles the user chose
    let recipe: Recipe
    
    /// I use this boolean to know if the user has tapped the screen to start playing
    @State private var hasStarted = false
    
    /// I turn this true when every single ingredient is fully prepped
    @State private var isDone = false
    
    /// I use this integer to track which ingredient in the array we are currently chopping
    @State private var currentIndex = 0
    
    /// I define the different states my interactive prep tool can be in
    enum PrepAction { case waiting, chopping, seasoning, gathering }
    
    /// I store the current mode of the tool right here
    @State private var currentAction: PrepAction = .waiting
    
    /// I use this asynchronous task to run my chopping animation loop in the background
    @State private var chopTask: Task<Void, Never>?
    
    /// I trigger this boolean to swap the whole emoji out for the sliced up pieces
    @State private var isSliced = false
    
    /// I use this decimal to fade the knife or hammer in and out smoothly
    @State private var toolOpacity: Double = 0.0
    
    /// I use this number to swing the tool up and down on the screen
    @State private var toolOffset: CGFloat = -80
    
    /// I use this boolean specifically to shake the salt shaker back and forth
    @State private var isAnimatingTool = false
    
    /// I use this memory to remember if the user has already seasoned the current item so they do not do it twice
    @State private var hasSeasonedCurrentItem = false
    
    /// I safely unwrap the prep instructions here or I create blank ones if none exist
    var preps: [IngredientPrep] {
        if let advanced = recipe.ingredientPreps, !advanced.isEmpty { return advanced }
        return recipe.requiredIngredients.map {
            IngredientPrep(name: $0, cutStyle: "None", preSeason: false)
        }
    }
    
    /// I build the main layout for the chopping minigame inside this body
    var body: some View {
        VStack {
            Text("Step 2: Prep time!")
                .font(.largeTitle.weight(.bold))
                .padding(.top, 50)
            
            Spacer()
            
            /// I use this stack to layer the food the sliced pieces and the tool on top of each other
            ZStack {
                Color.clear.frame(width: 250, height: 250)
                
                if isDone {
                    Text("✔️")
                        .font(.system(size: 120))
                        .transition(.scale.combined(with: .opacity))
                } else if currentIndex < preps.count {
                    let currentItem = preps[currentIndex]
                    let emoji = manager.availableIngredients
                        .first(where: { $0.name == currentItem.name })?.emoji ?? "🧅"
                    
                    /// I check if the tool just hit the food and swap in the broken pieces
                    if isSliced && currentAction == .chopping {
                        /// I call my beautifully organized animation block right here
                        animatedFoodPieces(for: currentItem.cutStyle, emoji: emoji, index: currentIndex)
                    } else {
                        /// I show the fully intact food emoji if the knife is lifted in the air
                        Text(emoji)
                            .font(.system(size: 90))
                            .transition(.scale)
                            .id("whole\(currentIndex)")
                    }
                    
                    /// I configure the chopping tool based on what the user selected earlier
                    if currentAction == .chopping {
                        let isPeel = currentItem.cutStyle == "Peel"
                        let tool = currentItem.cutStyle == "Smash" ? "🔨" : (isPeel ? "🪒" : "🔪")
                        
                        Text(tool)
                            .font(.system(size: 100))
                            .offset(x: isPeel ? -10 : 30, y: toolOffset)
                            .rotationEffect(.degrees(isPeel ? -20 : 0))
                            .opacity(toolOpacity)
                    }
                    else if currentAction == .seasoning {
                        Text("🧂")
                            .font(.system(size: 70))
                            .offset(x: 80, y: 180)
                            .rotationEffect(.degrees(isAnimatingTool ? -120 : -90), anchor: .bottomLeading)
                            .opacity(toolOpacity)
                            /// I attach the repeating animation specifically to the rotation so it shakes perfectly
                            .animation(.easeInOut(duration: 0.15).repeatForever(autoreverses: true), value: isAnimatingTool)
                            .onAppear {
                                /// I tell the shaker to start moving the exact moment it appears on the screen
                                isAnimatingTool = true
                            }
                    }
                }
            }
            
            Spacer()
            
            /// I use this bottom section to tell the user what they are currently doing
            VStack(spacing: 10) {
                if isDone {
                    Text("All Prepped!")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(Color.green)
                    Text("Swipe to cook! 👉")
                        .font(.headline)
                        .foregroundStyle(.tertiary)
                } else if currentIndex < preps.count {
                    let currentItem = preps[currentIndex]
                    
                    if !hasStarted {
                        Text("Tap anywhere to start prepping!")
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(Color.orange)
                    } else {
                        if currentAction == .gathering {
                            Text("Gather the \(currentItem.name)!")
                                .font(.title2.weight(.bold))
                                .foregroundStyle(Color.orange)
                        } else if currentAction == .chopping {
                            Text("\(currentItem.cutStyle) the \(currentItem.name)...")
                                .font(.title2.weight(.bold))
                                .foregroundStyle(Color.orange)
                        } else if currentAction == .seasoning {
                            let seasonText = recipe.seasoningsBefore.isEmpty ? "your favorite spices" : ListFormatter.localizedString(byJoining: recipe.seasoningsBefore)
                            Text("Add \(seasonText) to the \(currentItem.name)!")
                                .font(.title2.weight(.bold))
                                .foregroundStyle(Color.orange)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 20)
                                .lineLimit(3)
                                .minimumScaleFactor(0.5)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Text("Tap to continue")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.tertiary)
                            .padding(.top, 5)
                    }
                }
            }
            .frame(height: 80)
            .padding(.bottom, 60)
        }
        .contentShape(Rectangle())
        .onTapGesture {
            /// I trigger a soft haptic bump every single time the user taps the screen
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            handleScreenTap()
        }
        /// I make absolutely sure the background animation task stops if the user swipes away
        .onDisappear { chopTask?.cancel() }
    }
    
    /// MARK Animation Studio
    /// I created this animation studio to handle the different visual cut styles
    /// I use masks and rotation effects to visually break the emojis apart into custom pieces
    @ViewBuilder
    private func animatedFoodPieces(for style: String, emoji: String, index: Int) -> some View {
        if style == "Smash" {
            /// I scatter a messy broken pattern here for the smash effect
            ZStack {
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: -22.5, y: -22.5)).offset(x: -25, y: -15).rotationEffect(.degrees(-20))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: 22.5, y: -22.5)).offset(x: 25, y: -10).rotationEffect(.degrees(25))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: -22.5, y: 22.5)).offset(x: -20, y: 25).rotationEffect(.degrees(-15))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: 22.5, y: 22.5)).offset(x: 25, y: 25).rotationEffect(.degrees(20))
            }
            .transition(.scale).id("smashed\(index)")
            
        } else if style == "Peel" {
            /// I shave the sides off the food to make it look peeled
            ZStack {
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 60, height: 100))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 15, height: 100).offset(x: -35)).offset(x: -30, y: 30).rotationEffect(.degrees(-30)).opacity(0.3)
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 15, height: 100).offset(x: 35)).offset(x: 30, y: 30).rotationEffect(.degrees(30)).opacity(0.3)
            }
            .transition(.scale).id("peeled\(index)")
            
        } else if style == "Halve" {
            /// I make one clean cut directly down the center here
            ZStack {
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 90).offset(x: -22.5)).offset(x: -20, y: 15).rotationEffect(.degrees(-20))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 90).offset(x: 22.5)).offset(x: 20, y: 15).rotationEffect(.degrees(20))
            }
            .transition(.scale).id("halve\(index)")
            
        } else if style == "Chop" {
            /// I create three chunky horizontal pieces here
            ZStack {
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 90, height: 30).offset(y: -30)).offset(x: -15, y: -20).rotationEffect(.degrees(-15))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 90, height: 30)).offset(x: 10, y: 5).rotationEffect(.degrees(10))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 90, height: 30).offset(y: 30)).offset(x: -10, y: 25).rotationEffect(.degrees(-5))
            }
            .transition(.scale).id("chop\(index)")
            
        } else if style == "Dice" {
            /// I scatter a clean and perfect square grid here
            ZStack {
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: -22.5, y: -22.5)).offset(x: -25, y: -25).rotationEffect(.degrees(-15))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: 22.5, y: -22.5)).offset(x: 25, y: -25).rotationEffect(.degrees(15))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: -22.5, y: 22.5)).offset(x: -25, y: 25).rotationEffect(.degrees(-15))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 45, height: 45).offset(x: 22.5, y: 22.5)).offset(x: 25, y: 25).rotationEffect(.degrees(15))
            }
            .transition(.scale).id("dice\(index)")
            
        } else if style == "Mince" {
            /// I shrink the pieces slightly and scatter them everywhere to look minutely chopped
            ZStack {
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: -30, y: -30)).offset(x: -35, y: -35).rotationEffect(.degrees(-45))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: 0, y: -30)).offset(x: 0, y: -40).rotationEffect(.degrees(20))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: 30, y: -30)).offset(x: 35, y: -35).rotationEffect(.degrees(45))
                
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: -30, y: 0)).offset(x: -40, y: 0).rotationEffect(.degrees(-30))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: 0, y: 0)).offset(x: 5, y: 5).rotationEffect(.degrees(15))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: 30, y: 0)).offset(x: 40, y: 0).rotationEffect(.degrees(30))
                
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: -30, y: 30)).offset(x: -35, y: 35).rotationEffect(.degrees(-60))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: 0, y: 30)).offset(x: -5, y: 40).rotationEffect(.degrees(-10))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 30).offset(x: 30, y: 30)).offset(x: 35, y: 35).rotationEffect(.degrees(60))
            }
            .scaleEffect(0.8)
            .transition(.scale).id("mince\(index)")
            
        } else {
            /// I use three clean vertical slices as my default fallback just in case
            ZStack {
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 90).offset(x: -30)).offset(x: -20, y: 10).rotationEffect(.degrees(-15))
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 90)).offset(y: 5)
                Text(emoji).font(.system(size: 90)).mask(Rectangle().frame(width: 30, height: 90).offset(x: 30)).offset(x: 20, y: 10).rotationEffect(.degrees(15))
            }
            .transition(.scale).id("sliced\(index)")
        }
    }
    
    /// MARK Logic Handlers
    /// I use this function to decide what happens every single time the user taps the screen
    func handleScreenTap() {
        if isDone { return }
        
        if !hasStarted {
            hasStarted = true
            startAction(.chopping)
        } else {
            /// I immediately stop the knife animation so it does not keep swinging
            chopTask?.cancel()
            let currentItem = preps[currentIndex]
            
            /// I check if this specific item needs seasoning and we have not seasoned it yet
            if currentItem.preSeason && !hasSeasonedCurrentItem && currentAction != .seasoning {
                startAction(.seasoning)
            } else {
                /// I move to the next ingredient in the list
                currentIndex += 1
                if currentIndex < preps.count {
                    hasSeasonedCurrentItem = false
                    startAction(.chopping)
                } else {
                    /// I celebrate that all the ingredients are completely finished
                    withAnimation { isDone = true; toolOpacity = 0 }
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            }
        }
    }
    
    /// I use this function to configure the exact tool and animation needed for the current mode
    func startAction(_ action: PrepAction) {
        var finalAction = action
        let currentStyle = preps[currentIndex].cutStyle
        
        /// I override the chop action and just gather the food if the user selected no cut style
        if action == .chopping && (currentStyle == "None" || currentStyle.isEmpty) { finalAction = .gathering }
        
        withAnimation {
            currentAction = finalAction
            isSliced = false
            toolOpacity = 0
            toolOffset = -80
        }
        
        if finalAction == .seasoning { hasSeasonedCurrentItem = true }
        
        if finalAction == .chopping {
            chopTask?.cancel()
            /// I spin up a brand new background task to start the swinging loop
            chopTask = Task { await runChopLoop() }
        }
        else if finalAction == .seasoning {
            /// I tell the sound manager to play the audio the moment the shaker appears
            SoundManager.shared.playSound(named: "seasoning")
            
            /// I trigger a gentle back and forth shake for the salt shaker
            withAnimation(.easeInOut(duration: 0.15).repeatForever(autoreverses: true)) {
                isAnimatingTool = true
                toolOpacity = 1.0
            }
        }
    }
    
    /// I built this asynchronous loop to physically swing the knife or hammer up and down
    func runChopLoop() async {
        let currentStyle = preps[currentIndex].cutStyle
        let hapticStyle: UIImpactFeedbackGenerator.FeedbackStyle = currentStyle == "Smash" ? .heavy : .medium
        
        while !Task.isCancelled {
            /// I step one lift the tool into the air completely silently
            withAnimation(.easeOut(duration: 0.2)) { toolOpacity = 0.0; toolOffset = -80; isSliced = false }
            
            try? await Task.sleep(nanoseconds: 500_000_000)
            guard !Task.isCancelled else { return }
            
            /// I step two make the tool appear and hover menacingly
            withAnimation(.easeIn(duration: 0.3)) { toolOpacity = 1.0 }
            try? await Task.sleep(nanoseconds: 400_000_000)
            guard !Task.isCancelled else { return }
            
            /// I step three swing the tool down quickly
            withAnimation(.easeInOut(duration: 0.4)) { toolOffset = 10 }
            try? await Task.sleep(nanoseconds: 400_000_000)
            guard !Task.isCancelled else { return }
            
            /// I step four trigger the exact moment of impact and shatter the food
            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { isSliced = true }
            
            /// I check the current cut style so I can ask the sound manager for the perfect audio file
            let soundToPlay: String
            if currentStyle == "Smash" {
                soundToPlay = "smash"
            }
            else if currentStyle == "Peel" {
                soundToPlay = "peel"
            }
            else {
                soundToPlay = "chop_hit"
            }
            
            /// I pass that dynamic name into my sound manager to play the right sound effect
            SoundManager.shared.playSound(named: soundToPlay)
            
            /// I pop the taptic engine to make the hit feel real in the users hand
            UIImpactFeedbackGenerator(style: hapticStyle).impactOccurred()
            
            withAnimation(.easeOut(duration: 0.2)) { toolOpacity = 0.0 }
            try? await Task.sleep(nanoseconds: 2_500_000_000)
        }
    }
}
