import SwiftUI

/// MARK Interactive Cook Timeline
/// I built this interactive timeline to guide the user through the actual cooking and heating process
/// It reads the timeline batches we created earlier and plays them out like a script
struct CookStepView: View {
    
    /// I bring in the manager to match ingredient names to their emojis
    @EnvironmentObject var manager: RecipeManager
    
    /// I hold the current recipe data here
    let recipe: Recipe
    
    /// I created this enumeration to tell the timeline exactly what type of step is happening right now
    enum CookEvent {
        /// I changed this to use AttributedString so I can easily support bold markdown text
        case prompt(title: AttributedString, button: String)
        /// I use this case to tell the app to run a timer for a specific number of seconds
        case cook(time: Int)
        /// I use this case to signal that the entire heating process is completely finished
        case done
    }
    
    /// I hold the generated sequence of events in this array
    @State private var events: [CookEvent] = []
    
    /// I track which part of the script we are currently executing
    @State private var currentEventIndex = 0
    
    /// I keep track of how many seconds are left on the clock right here
    @State private var timeRemaining = 0
    
    /// I use this boolean to pause and unpause the clock
    @State private var isTimerRunning = false
    
    /// I use this boolean to turn the visual fire and bubbling animations on and off
    @State private var isCookingAnimationOn = false
    
    /// I set up an automatic publisher that fires every single second to drive my clock
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    /// I build the primary view structure inside this body
    var body: some View {
        VStack(spacing: 40) {
            Text("Step 3: \(recipe.method) time!")
                .font(.title2.weight(.bold))
            
            let method = recipe.method.lowercased()
            let firstIngredient = recipe.requiredIngredients.first ?? ""
            let dynamicEmoji = manager.availableIngredients.first(where: { $0.name == firstIngredient })?.emoji ?? "🥦"
            
            /// I extracted this massive graphics logic into a helper function below so the compiler does not struggle
            cookingAnimationLayer(method: method, dynamicEmoji: dynamicEmoji)
                .frame(height: 250)
                .animation(isTimerRunning ? .easeInOut(duration: 0.8).repeatForever(autoreverses: true) : .easeOut(duration: 0.3), value: isCookingAnimationOn)
            
            VStack {
                if !events.isEmpty {
                    let currentEvent = events[currentEventIndex]
                    switch currentEvent {
                    case .prompt(let title, let buttonText):
                        /// I render the instructional text telling the user what to drop into the pan
                        Text(title)
                            .font(.title3)
                            .foregroundStyle(.orange)
                            .multilineTextAlignment(.center)
                            .lineLimit(4)
                            .minimumScaleFactor(0.6)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.horizontal, 20)
                            .transition(.scale.combined(with: .opacity))
                        
                        Button {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            advanceScript()
                        } label: {
                            Text(buttonText)
                                .font(.headline.weight(.semibold))
                                .frame(maxWidth: .infinity)
                        }
                        .controlSize(.extraLarge)
                        .buttonStyle(.glassProminent)
                        .tint(.orange)
                        .padding(.horizontal, 40)
                        .padding(.top, 10)
                        
                    case .cook(_):
                    /// I render the large countdown clock right here
                    Text(String(format: "%02d:%02d", timeRemaining / 60, timeRemaining % 60))
                        .font(.system(size: 50, weight: .bold, design: .monospaced))
                        .foregroundStyle(.orange)
                        /// I kept a tap gesture here so the user can quickly skip the wait
                        .onTapGesture { timeRemaining = 1 }
                        .transition(.scale.combined(with: .opacity))
                    
                    Text("Cooking in progress...")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    
                    /// I added this tiny subtle hint so the user knows about the secret skip feature
                    Text("Tap the clock to fast forward")
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                        .padding(.top, 2)
                        
                    case .done:
                        /// I render the celebration text when the timer hits zero for the last time
                        Text("Cooking Complete! 🔔")
                            .font(.title2.weight(.bold))
                            .foregroundStyle(.green)
                            .transition(.scale.combined(with: .opacity))
                            .onAppear {
                                SoundManager.shared.playSound(named: "cooking_completed")
                                UINotificationFeedbackGenerator().notificationOccurred(.success)
                            }
                        Text("Swipe to plate! 👉")
                            .foregroundStyle(.tertiary)
                            .padding(.top, 5)
                    }
                }
            }
            .frame(height: 160)
        }
        /// I trigger the script builder the moment this view appears on the screen
        .onAppear { if events.isEmpty { buildScript() } }
        /// I catch the ticking clock signals right here to update my time remaining
        .onReceive(timer) { _ in
            if isTimerRunning && timeRemaining > 0 {
                timeRemaining -= 1
            } else if isTimerRunning && timeRemaining == 0 {
                isTimerRunning = false
                isCookingAnimationOn = false
                
                /// I play the alarm bell sound effect to alert the chef that the time is up
                SoundManager.shared.playSound(named: "alarm_zero")
                advanceScript()
            }
        }
    }
    
    /// MARK Visual Graphics
    /// I built this view builder to draw the flames and bubbles underneath the food
    @ViewBuilder
    private func cookingAnimationLayer(method: String, dynamicEmoji: String) -> some View {
        ZStack {
            if method == "fry" {
                Text("🔥").font(.system(size: 100)).offset(y: 60)
                    .scaleEffect(isCookingAnimationOn ? 1.2 : 0.8)
                    .opacity(isTimerRunning ? (isCookingAnimationOn ? 1.0 : 0.7) : 0.0)
                Text("🍳").font(.system(size: 140))
            } else if method == "boil" {
                Text("🍲").font(.system(size: 140))
                Text("🫧").font(.system(size: 60))
                    .offset(y: isCookingAnimationOn ? -80 : 0)
                    .opacity(isTimerRunning ? (isCookingAnimationOn ? 0.0 : 1.0) : 0.0)
            } else if method == "steam" {
                Text("♨️").font(.system(size: 80)).offset(y: 90)
                    .scaleEffect(isCookingAnimationOn ? 1.1 : 0.9)
                    .opacity(isTimerRunning ? (isCookingAnimationOn ? 1.0 : 0.6) : 0.2)
                Text(dynamicEmoji).font(.system(size: 90))
                    .offset(y: isCookingAnimationOn ? -5 : 5)
                Text("🫧").font(.system(size: 50))
                    .offset(x: 25, y: isCookingAnimationOn ? -80 : -20)
                    .scaleEffect(isCookingAnimationOn ? 1.2 : 0.5)
                    .opacity(isTimerRunning ? 0.8 : 0.0)
                Text("💨").font(.system(size: 50))
                    .rotationEffect(.degrees(-90))
                    .offset(x: -25, y: isCookingAnimationOn ? -90 : -30)
                    .scaleEffect(isCookingAnimationOn ? 1.5 : 0.5)
                    .opacity(isTimerRunning ? 0.7 : 0.0)
            } else if method == "grill" {
                Text("🔥").font(.system(size: 90)).offset(y: 40)
                    .scaleEffect(x: isCookingAnimationOn ? 1.1 : 0.9, y: isCookingAnimationOn ? 1.3 : 0.8)
                    .opacity(isTimerRunning ? (isCookingAnimationOn ? 1.0 : 0.8) : 0.0)
                Text(dynamicEmoji).font(.system(size: 110)).offset(y: -20)
            } else {
                Text("🎛️").font(.system(size: 140))
                RoundedRectangle(cornerRadius: 5, style: .continuous)
                    .fill(LinearGradient(colors: [Color.red.opacity(0.8), Color.orange.opacity(0.5)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: 80, height: 15)
                    .opacity(isTimerRunning ? (isCookingAnimationOn ? 1.0 : 0.2) : 0.0)
                    .shadow(color: .red, radius: isCookingAnimationOn ? 10 : 0)
            }
        }
    }
    
    /// MARK Script Logic
    /// I built this helper function to easily convert my standard strings into attributed markdown strings
    private func boldString(_ text: String) -> AttributedString {
        return try! AttributedString(markdown: text)
    }
    
    /// I analyze the recipes data right here to build a custom step by step timeline sequence
    func buildScript() {
        var script: [CookEvent] = []
        let container: String
        switch recipe.method.lowercased() {
            case "fry": container = "pan"
            case "boil": container = "pot"
            case "steam": container = "steamer"
            case "grill": container = "grill"
            default: container = "oven"
        }
        
        /// I check if the user built custom timeline phases and use those if they exist
        if let phases = recipe.cookPhases, !phases.isEmpty {
            for (index, phase) in phases.enumerated() {
                let boldedIngredients = phase.ingredients.map { "**\($0)**" }.joined(separator: " and ")
                
                script.append(.prompt(title: boldString("Add the \(boldedIngredients) to the \(container)."), button: "Drop in!"))
                
                if index == phases.count / 2 && !recipe.seasoningsDuring.isEmpty {
                    let boldSeasonings = recipe.seasoningsDuring.map { "**\($0)**" }.joined(separator: ", ")
                    script.append(.prompt(title: boldString("Time for flavor! Sprinkle in the \(boldSeasonings)."), button: "Season it!"))
                }
                if phase.cookTime > 0 { script.append(.cook(time: phase.cookTime * 60)) }
            }
        } else {
            /// I generate a basic fallback script if no custom phases were provided
            let items = Array(recipe.requiredIngredients)
            let totalSeconds = recipe.cookTime * 60
            
            if items.count > 1 {
                let half = items.count / 2
                let batch1 = Array(items.prefix(half)).map { "**\($0)**" }.joined(separator: " & ")
                let batch2 = Array(items.suffix(from: half)).map { "**\($0)**" }.joined(separator: " & ")
                
                script.append(.prompt(title: boldString("Add the \(batch1) to the \(container)."), button: "Drop in!"))
                script.append(.cook(time: totalSeconds / 2))
                
                var prompt2 = "Now add the \(batch2)."
                if !recipe.seasoningsDuring.isEmpty {
                    let boldSeasonings = recipe.seasoningsDuring.map { "**\($0)**" }.joined(separator: ", ")
                    prompt2 += " And sprinkle in the \(boldSeasonings)."
                }
                
                script.append(.prompt(title: boldString(prompt2), button: "Add & Continue"))
                script.append(.cook(time: totalSeconds / 2))
                
            } else {
                let item = "**\(items.first ?? "food")**"
                script.append(.prompt(title: boldString("Place the \(item) into the \(container)."), button: "Start Cooking"))
                
                if !recipe.seasoningsDuring.isEmpty {
                    let boldSeasonings = recipe.seasoningsDuring.map { "**\($0)**" }.joined(separator: ", ")
                    script.append(.cook(time: totalSeconds / 2))
                    script.append(.prompt(title: boldString("Time for flavor! Add the \(boldSeasonings)."), button: "Season it!"))
                    script.append(.cook(time: totalSeconds / 2))
                } else {
                    script.append(.cook(time: totalSeconds))
                }
            }
        }
        
        /// I push the final completion status onto the array and save the script
        script.append(.done)
        withAnimation { events = script }
    }
    
    /// I use this function to smoothly transition between reading instructions and watching the timer count down
    func advanceScript() {
        withAnimation {
            currentEventIndex += 1
            if currentEventIndex < events.count {
                if case .cook(let duration) = events[currentEventIndex] {
                    timeRemaining = duration
                    isTimerRunning = true
                    isCookingAnimationOn = true
                }
            }
        }
    }
}
