import SwiftUI

/// MARK Final Plating View
/// I created this final view to celebrate the finished dish and add any final garnishes
struct FinishStepView: View {
    
    /// I access the manager here so I can reset the pot data when they finish
    @EnvironmentObject var manager: RecipeManager
    
    /// I use this dismiss action to drop the sheet and return the user to the main menu
    @Environment(\.dismiss) var dismiss
    
    /// I hold the current recipe data right here
    let recipe: Recipe
    
    /// I use this state variable to animate the final dish onto the screen
    @State private var isPlated = false
    
    /// I check this boolean to ensure they complete the after cooking seasoning step
    @State private var hasFinishedPostSeasoning = false
    
    var body: some View {
        /// I made sure this vertical stack spacing matches the cooking step view perfectly for a seamless transition
        VStack(spacing: 40) {
            
            /// I check if the chef needs to add any final garnishes before seeing the plate
            if !recipe.seasoningsAfter.isEmpty && !hasFinishedPostSeasoning {
                Text("Wait! Final Touch!")
                    .font(.title2.weight(.bold))
                
                VStack {
                    Text("Add \(recipe.seasoningsAfter.joined(separator: ", "))")
                        .font(.title3.weight(.medium))
                        .foregroundStyle(Color.orange)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 16)
                        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .shadow(color: .black.opacity(0.04), radius: 10, y: 4)
                }
                .frame(height: 250)
                
                VStack {
                    Button {
                        UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                        withAnimation {
                            hasFinishedPostSeasoning = true
                            isPlated = true
                        }
                    } label: {
                        Text("Done!")
                            .font(.headline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .controlSize(.extraLarge)
                    .buttonStyle(.glassProminent)
                    .tint(.orange)
                    .padding(.horizontal, 40)
                    .padding(.top, 10)
                }
                .frame(height: 140)
                
            } else {
                /// I render the final celebration screen here
                Text("Enjoy!")
                    .font(.system(size: 40, weight: .heavy, design: .rounded))
                
                VStack {
                    Text(recipe.emoji)
                        .font(.system(size: 150))
                        .shadow(color: .black.opacity(0.1), radius: 15, y: 10)
                        .scaleEffect(isPlated ? 1.0 : 0.5)
                        .opacity(isPlated ? 1 : 0)
                }
                .frame(height: 250)
                
                VStack {
                    Text(recipe.name)
                        .font(.title.weight(.bold))
                        .foregroundStyle(Color.primary)
                    
                    if isPlated {
                        Button {
                            /// I wipe the pot entirely clean and send the user back to the home view
                            manager.clearPot()
                            manager.resetNavigation = true
                            dismiss()
                        } label: {
                            Text("Back to Kitchen")
                                .font(.headline.weight(.semibold))
                                .frame(maxWidth: .infinity)
                        }
                        .controlSize(.extraLarge)
                        .buttonStyle(.glassProminent)
                        .tint(.green)
                        .padding(.horizontal, 40)
                        .padding(.top, 10)
                        .transition(.scale.combined(with: .opacity))
                    }
                }
                .frame(height: 140)
            }
        }
        /// I trigger the plating animation immediately if there are no post cooking seasonings to add
        .onAppear {
            if recipe.seasoningsAfter.isEmpty {
                hasFinishedPostSeasoning = true
                withAnimation(.spring(response: 0.6, dampingFraction: 0.5)) { isPlated = true }
            }
        }
    }
}
