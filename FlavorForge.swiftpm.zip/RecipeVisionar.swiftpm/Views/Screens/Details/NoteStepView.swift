import SwiftUI

/// MARK Chefs Notes View
/// I built this view to display the custom notes checklist before the cooking actually starts
/// This acts as a safety stop so the user reads the instructions
struct NoteStepView: View {
    
    /// I hold the current recipe data right here
    let recipe: Recipe
    
    /// I use this specific set to remember which notes the user has successfully checked off
    @State private var checkedNotes: Set<Int> = []
    
    /// I use this helper to safely extract the notes array or return a blank list
    var notes: [String] { recipe.notes ?? [] }
    
    /// I assemble the visual layout inside this body variable
    var body: some View {
        VStack {
            Text("Chef's Notes 📝")
                .font(.largeTitle.weight(.bold))
                .padding(.top, 50)
            
            if notes.isEmpty {
                Spacer()
                Text("No special notes for this recipe.")
                    .font(.title3)
                    .foregroundStyle(.secondary)
                Spacer()
            } else {
                List {
                    Section {
                        /// I loop through the array using enumerated so I can track the index position for checkboxes
                        ForEach(Array(notes.enumerated()), id: \.offset) { index, note in
                            let isChecked = checkedNotes.contains(index)
                            
                            Button {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                    if isChecked { checkedNotes.remove(index) }
                                    else { checkedNotes.insert(index) }
                                }
                            } label: {
                                /// I use a semantic label here to cleanly separate the text from the visual icon
                                Label {
                                    Text(note)
                                        .font(.body)
                                        .foregroundStyle(isChecked ? .secondary : .primary)
                                        .strikethrough(isChecked, color: Color.secondary)
                                } icon: {
                                    Image(systemName: isChecked ? "checkmark.circle.fill" : "circle")
                                        .font(.title2)
                                        .foregroundStyle(isChecked ? Color.green : Color.orange.opacity(0.5))
                                        .scaleEffect(isChecked ? 1.1 : 1.0)
                                }
                                .padding(.vertical, 8)
                            }
                            .buttonStyle(.plain)
                        }
                    } header: {
                        Text("Instructions & Tips").font(.headline)
                    }
                }
                .scrollContentBackground(.hidden)
                .scrollEdgeEffectStyle(.automatic, for: .all)
                .padding(.top, 10)
            }
            
            VStack {
                Text("Swipe to cook! 👉")
                    .font(.headline)
                    .foregroundStyle(.tertiary)
            }
            .frame(height: 80)
            .padding(.bottom, 60)
        }
        .onAppear {
            /// I play a sound right here to alert the user that there are important notes to read
            SoundManager.shared.playSound(named: "notes_page")
        }
    }
}
