import SwiftUI

/// MARK Prep Step View
/// I built this view for the very first step where the user gathers their ingredients
/// I want the user to see everything they need before they start cooking
struct PrepStepView: View {
    
    /// I inject the recipe manager so I can match the required ingredients to their emojis
    @EnvironmentObject var manager: RecipeManager
    
    /// I store the recipe data here so I know what ingredients to display
    let recipe: Recipe
    
    /// I build the screen layout inside this body variable
    var body: some View {
        VStack {
            /// I added a large bold title to welcome the user to the prep stage
            Text("Gather Ingredients")
                .font(.largeTitle.weight(.bold))
                .padding(.top, 50)
            
            Spacer()
            
            /// I wrap the food grid and the seasoning box inside this vertical stack
            VStack(spacing: 40) {
                
                /// I filter my entire database to only find the ingredients required for this specific dish
                let items = manager.availableIngredients.filter {
                    recipe.requiredIngredients.contains($0.name)
                }
                
                /// I use a lazy grid to beautifully arrange the food emojis on the screen
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 80), spacing: 15)], spacing: 20) {
                    
                    /// I am reusing my staggered entrance animation pattern here for a beautiful popping effect
                    ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                        StaggeredAppearView(index: index) {
                            IngredientBubble(emoji: item.emoji)
                        }
                    }
                }
                .padding(.horizontal, 20)
                
                /// I check if there are any spices needed before cooking begins
                if !recipe.seasoningsBefore.isEmpty {
                    /// I display those spices in a clean glass box so the user remembers to grab them
                    VStack(spacing: 8) {
                        Text("Seasoning required:")
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.secondary)
                        Text(recipe.seasoningsBefore.joined(separator: ", "))
                            .font(.headline)
                            .foregroundStyle(.orange)
                    }
                    .padding(.vertical, 16)
                    .padding(.horizontal, 24)
                    .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: .black.opacity(0.04), radius: 10, y: 4)
                }
            }
            
            Spacer()
            
            /// I give the user a clear instruction on how to proceed to the next page
            VStack {
                Text("Swipe to prep! 👉")
                    .font(.headline)
                    .foregroundStyle(.tertiary)
            }
            .frame(height: 80)
            .padding(.bottom, 60)
        }
    }
}

/// MARK Ingredient Bubble Component
/// I simplified this bubble view since the pop animation is handled by the staggered appear view
/// I use this specifically to make the food emojis look like they are floating on glass buttons
struct IngredientBubble: View {
    
    /// I pass the string of the emoji into this property
    let emoji: String
    
    /// I render the visual circle inside this body
    var body: some View {
        Text(emoji)
            .font(.system(size: 45))
            .frame(width: 80, height: 80)
            .glassEffect(.regular, in: Circle())
            .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
    }
}
