import SwiftUI

struct MatchedRecipesView: View {
    @EnvironmentObject var manager: RecipeManager
    
    /// This holds the list of recipes that matched the pot
    let recipes: [Recipe]
    
    var body: some View {
        ZStack {
            /// Standard native background color
            Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
            
            /// left/right swiping
            TabView {
                ForEach(recipes) { recipe in
                    VStack(spacing: 30) {
                        Spacer()
                        
                        /// A beautifully elevated Liquid Glass Hero Card
                        VStack(spacing: 24) {
                            /// The Giant Food Icon
                            Text(recipe.emoji)
                                .font(.system(size: 160))
                                .shadow(color: .black.opacity(0.15), radius: 20, y: 15)
                            
                            /// The Dish Name & Info
                            VStack(spacing: 12) {
                                Text(recipe.name)
                                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                                    .multilineTextAlignment(.center)
                                    .foregroundStyle(.primary)
                                
                                HStack(spacing: 8) {
                                    Text(recipe.method)
                                        .font(.subheadline.weight(.bold))
                                        .foregroundStyle(.orange)
                                        .textCase(.uppercase)
                                    
                                    Text("•")
                                        .foregroundStyle(.tertiary)
                                    
                                    Text("\(recipe.cookTime) MINS")
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .padding(.vertical, 40)
                        .padding(.horizontal, 20)
                        .frame(maxWidth: .infinity)
                        /// Wrapping the hero content in a fluid glass material
                        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 32, style: .continuous))
                        .shadow(color: .black.opacity(0.04), radius: 15, y: 8)
                        .padding(.horizontal, 24)
                        
                        Spacer()
                        
                        /// The Link to the Detail Page
                        NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                            Text("How to cook this")
                                .font(.title3.weight(.bold))
                                .frame(maxWidth: .infinity)
                        }
                        /// Native sizing and glass styling for the CTA
                        .controlSize(.extraLarge)
                        .buttonStyle(.glassProminent)
                        .tint(.orange)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .padding(.horizontal, 40)
                        .padding(.bottom, 60)
                        // Adds a satisfying click when navigating
                        .simultaneousGesture(TapGesture().onEnded {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        })
                    }
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
        .navigationTitle("Matches Found!")
        .navigationBarTitleDisplayMode(.inline)
    }
}
