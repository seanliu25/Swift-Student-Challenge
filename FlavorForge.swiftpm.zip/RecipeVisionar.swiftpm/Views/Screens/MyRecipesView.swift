import SwiftUI

struct MyRecipesView: View {
    @EnvironmentObject var manager: RecipeManager
    
    // State variable for what the user types in the search bar
    @State private var searchText = ""
    
    // Computes which recipes to show based on the search text
    var filteredRecipes: [Recipe] {
        if searchText.isEmpty {
            return manager.recipeDatabase
        } else {
            return manager.recipeDatabase.filter { recipe in
                // Searches by recipe name OR ingredient name!
                recipe.name.localizedCaseInsensitiveContains(searchText) ||
                recipe.requiredIngredients.contains { $0.localizedCaseInsensitiveContains(searchText) }
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Native system background
                Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                
                // Grouping allows us to smoothly crossfade between empty states and the list
                Group {
                    if manager.recipeDatabase.isEmpty {
                        emptyDatabaseView
                    }
                    else if filteredRecipes.isEmpty {
                        emptySearchView
                    }
                    else {
                        recipeList
                    }
                }
                // Smoothly transitions between states when searching/deleting
                .animation(.spring(response: 0.4, dampingFraction: 0.8), value: filteredRecipes.count)
            }
            .navigationTitle("My Recipes")
            // The magical searchable modifier:
            .searchable(text: $searchText, prompt: "Search recipes or ingredients...")
        }
    }
    
    // MARK: - View Components
    
    @ViewBuilder
    private var emptyDatabaseView: some View {
        VStack(spacing: 12) {
            Image(systemName: "text.book.closed")
                .font(.system(size: 60))
                .foregroundStyle(.tertiary)
            Text("No recipes yet!")
                .font(.title2.weight(.bold))
                .foregroundStyle(.primary)
            Text("Go to the Create tab to make some magic.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding()
        .transition(.opacity.combined(with: .scale(scale: 0.95)))
    }
    
    @ViewBuilder
    private var emptySearchView: some View {
        VStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 60))
                .foregroundStyle(.tertiary)
            Text("No matches found")
                .font(.title2.weight(.bold))
                .foregroundStyle(.primary)
            Text("Try a different search term or ingredient.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding()
        .transition(.opacity.combined(with: .scale(scale: 0.95)))
    }
    
    @ViewBuilder
    private var recipeList: some View {
        List {
            ForEach(filteredRecipes) { recipe in
                NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                    HStack(spacing: 16) {
                        //  Upgraded the avatar circle:
                        Text(recipe.emoji)
                            .font(.system(size: 36))
                            .frame(width: 60, height: 60)
                            .glassEffect(.regular, in: Circle())
                            .shadow(color: .black.opacity(0.06), radius: 6, y: 3)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(recipe.name)
                                .font(.headline.weight(.semibold))
                                .foregroundStyle(.primary)
                            
                            // Shows a summary of the ingredients
                            Text(recipe.requiredIngredients.joined(separator: ", "))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                        }
                        
                        Spacer()
                        
                        VStack(alignment: .trailing, spacing: 6) {
                            Text(recipe.method)
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.orange)
                                .textCase(.uppercase)
                            
                            Text("\(recipe.cookTime)m")
                                .font(.caption2.weight(.medium))
                                .foregroundStyle(.tertiary)
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .onDelete(perform: deleteSafeRecipe)
        }
        .scrollContentBackground(.hidden)
        .scrollEdgeEffectStyle(.automatic, for: .all)
//        Ensure it drag the list down pulls the keyboard away.
        .scrollDismissesKeyboard(.interactively)
    }
    
    // MARK: - Logic
    
    func deleteSafeRecipe(at offsets: IndexSet) {
        //Satisfying feedback when a user deletes a recipe
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        
        for index in offsets {
            let recipeToDelete = filteredRecipes[index]
            if let actualIndex = manager.recipeDatabase.firstIndex(where: { $0.id == recipeToDelete.id }) {
                manager.deleteRecipe(at: IndexSet(integer: actualIndex))
            }
        }
    }
}
