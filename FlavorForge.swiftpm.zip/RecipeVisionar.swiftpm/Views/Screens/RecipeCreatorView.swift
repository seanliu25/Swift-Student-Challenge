import SwiftUI

/// This is the master view that manages the entire creator experience
/// I broke out all the individual steps into their own clean files
/// This view just handles the memory and swiping between pages
struct RecipeCreatorView: View {
    @EnvironmentObject var manager: RecipeManager
    
    @State private var currentStep = 0
    @State private var customName = ""
    @State private var customEmoji = "🍲"
    @State private var showEmojiPicker = false
    @State private var selectedMethod = "Boil"
    
    @State private var selectedIngredients: Set<String> = []
    @State private var itemCutStyles: [String: String] = [:]
    @State private var itemPreSeasoning: [String: Bool] = [:]
    let cutStyles = ["None", "Chop", "Dice", "Slice", "Mince", "Halve", "Peel", "Smash"]
    
    @State private var selectedCategory: IngredientCategory? = nil
    
    @State private var cookPhases: [CookPhase] = []
    @State private var stagedIngredients: [String] = []
    @State private var phaseTime: Double = 5.0
    
    @State private var timelineDraggingItem: String? = nil
    @State private var isHoveringTimelinePot = false
    
    @State private var availableSeasonings = ["Salt", "Pepper", "Garlic Powder", "Honey Sauce", "Soy Sauce", "Olive Oil", "vinegar", "Lemon Juice", "Ranch", "Honey Muster", "Barbecue sauce", "Ketchup"]
    @State private var customSeasoningText = ""
    @State private var seasoningsBefore: [String] = []
    @State private var seasoningsDuring: [String] = []
    @State private var seasoningsAfter: [String] = []
    
    @State private var draggingSeasoning: String? = nil
    @State private var dragLocation: CGPoint = .zero
    @State private var hoveredZone: String? = nil
    
    @State private var customNotes: [String] = []
    @State private var newNoteText: String = ""
    
    /// I use these saved memories to track every single tutorial step
    @AppStorage("hasSeenCreatorTutorial") private var hasSeenCreatorTutorial = false
    @AppStorage("hasSeenStep2Tutorial") private var hasSeenStep2Tutorial = false
    @AppStorage("hasSeenStep3Tutorial") private var hasSeenStep3Tutorial = false
    @AppStorage("hasSeenStep4Tutorial") private var hasSeenStep4Tutorial = false
    @AppStorage("hasSeenStep5Tutorial") private var hasSeenStep5Tutorial = false
    @AppStorage("hasSeenStep6Tutorial") private var hasSeenStep6Tutorial = false
    
    @State private var showSavedAlert = false
    
    /// I use these variables to animate the multi page tutorials
    @State private var tutorialStep = 1
    @State private var step5TutorialPage = 1
    
    let methods = ["Boil": "🍲", "Fry": "🍳", "Bake": "🎛️", "Steam": "♨️", "Grill": "🔥"]
    
    var body: some View {
        NavigationStack {
            GeometryReader { geo in
                ZStack {
                    Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                        .onTapGesture { hideKeyboard() }
                    
                    VStack {
                        ProgressView(value: Double(currentStep + 1), total: 7.0)
                            .tint(.orange)
                            .padding()
                        
                        TabView(selection: $currentStep) {
                            CreatorStep1View(customEmoji: $customEmoji, showEmojiPicker: $showEmojiPicker, customName: $customName, selectedMethod: $selectedMethod, methods: methods).tag(0)
                            
                            CreatorStep2View(selectedCategory: $selectedCategory, selectedIngredients: $selectedIngredients, cookPhases: $cookPhases, stagedIngredients: $stagedIngredients, geo: geo).tag(1)
                            
                            CreatorStep3View(selectedIngredients: $selectedIngredients, itemCutStyles: $itemCutStyles, itemPreSeasoning: $itemPreSeasoning, cutStyles: cutStyles).tag(2)
                            
                            CreatorStep4View(customNotes: $customNotes, newNoteText: $newNoteText).tag(3)
                            
                            CreatorStep5View(selectedIngredients: $selectedIngredients, cookPhases: $cookPhases, stagedIngredients: $stagedIngredients, phaseTime: $phaseTime, timelineDraggingItem: $timelineDraggingItem, isHoveringTimelinePot: $isHoveringTimelinePot, dragLocation: $dragLocation, geo: geo).tag(4)
                            
                            CreatorStep6View(customSeasoningText: $customSeasoningText, availableSeasonings: $availableSeasonings, seasoningsBefore: $seasoningsBefore, seasoningsDuring: $seasoningsDuring, seasoningsAfter: $seasoningsAfter, draggingSeasoning: $draggingSeasoning, dragLocation: $dragLocation, hoveredZone: $hoveredZone, geo: geo).tag(5)
                            
                            CreatorStep7View(customName: $customName, customEmoji: $customEmoji, selectedMethod: $selectedMethod, selectedIngredients: $selectedIngredients, seasoningsBefore: $seasoningsBefore, seasoningsDuring: $seasoningsDuring, seasoningsAfter: $seasoningsAfter, itemCutStyles: $itemCutStyles, itemPreSeasoning: $itemPreSeasoning, cookPhases: $cookPhases, customNotes: $customNotes, phaseTime: $phaseTime, showSavedAlert: $showSavedAlert, methods: methods).tag(6)
                        }
                        .tabViewStyle(.page(indexDisplayMode: .never))
                        
                        navigationButtons
                    }
                    
                    /// I placed all the tutorial triggers right here
                    if currentStep == 0 && !hasSeenCreatorTutorial {
                        creatorSpotlightTutorial.transition(.opacity).zIndex(100)
                    }
                    if currentStep == 1 && !hasSeenStep2Tutorial {
                        step2SpotlightTutorial.transition(.opacity).zIndex(101)
                    }
                    if currentStep == 2 && !hasSeenStep3Tutorial {
                        step3SpotlightTutorial.transition(.opacity).zIndex(102)
                    }
                    if currentStep == 3 && !hasSeenStep4Tutorial {
                        step4SpotlightTutorial.transition(.opacity).zIndex(103)
                    }
                    if currentStep == 4 && !hasSeenStep5Tutorial {
                        step5SpotlightTutorial.transition(.opacity).zIndex(104)
                    }
                    if currentStep == 5 && !hasSeenStep6Tutorial {
                        step6SpotlightTutorial.transition(.opacity).zIndex(105)
                    }
                    
                    if let draggingItem = draggingSeasoning {
                        Text(draggingItem)
                            .padding(.vertical, 10).padding(.horizontal, 20)
                            .glassEffect(.regular, in: Capsule())
                            .shadow(color: .black.opacity(0.15), radius: 12, y: 8)
                            .position(dragLocation)
                            .ignoresSafeArea()
                    }
                    
                    if let draggingTimeItem = timelineDraggingItem {
                        let emoji = manager.availableIngredients.first(where: { $0.name == draggingTimeItem })?.emoji ?? "🍲"
                        Text(emoji)
                            .font(.system(size: 60)).frame(width: 90, height: 90)
                            .glassEffect(.regular, in: Circle())
                            .shadow(color: .black.opacity(0.15), radius: 12, y: 8)
                            .position(dragLocation)
                            .ignoresSafeArea()
                    }
                }
            }
            .navigationTitle("Recipe Creator")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Recipe Saved! 🧑‍🍳", isPresented: $showSavedAlert) {
                Button("Awesome!") { resetCreator() }
            }
            .sheet(isPresented: $showEmojiPicker) {
                RecipeIconPickerSheet(selectedEmoji: $customEmoji)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
            /// Tester control:
//            .onAppear {
//                hasSeenCreatorTutorial = false
//                hasSeenStep2Tutorial = false
//                hasSeenStep3Tutorial = false
//                hasSeenStep4Tutorial = false
//                hasSeenStep5Tutorial = false
//                hasSeenStep6Tutorial = false
//                tutorialStep = 1
//                step5TutorialPage = 1
//            }
        }
    }
    
    @ViewBuilder
    private var navigationButtons: some View {
        HStack {
            if currentStep > 0 {
                Button {
                    hideKeyboard()
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation { currentStep -= 1 }
                } label: {
                    Text("Back").font(.headline.weight(.medium)).frame(minWidth: 80).padding(.vertical, 12)
                }
                .buttonStyle(.glass)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            Spacer()
            if currentStep < 6 {
                Button {
                    hideKeyboard()
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation { currentStep += 1 }
                } label: {
                    Text("Next").font(.headline.weight(.semibold)).frame(minWidth: 100).padding(.vertical, 12)
                }
                .buttonStyle(.glassProminent)
                .tint(.orange)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .disabled(
                    (currentStep == 1 && selectedIngredients.isEmpty) ||
                    (currentStep == 4 && cookPhases.flatMap { $0.ingredients }.count != selectedIngredients.count)
                )
            }
        }
        .padding()
    }
    
    /// I built this multi page tutorial for the first screen
    @ViewBuilder
    private var creatorSpotlightTutorial: some View {
        ZStack {
            if tutorialStep == 1 {
                ZStack {
                    Color.black.opacity(0.7)
                        .ignoresSafeArea()
                        .reverseMask {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .frame(height: 55)
                                .padding(.horizontal, 16)
                                .frame(maxHeight: .infinity, alignment: .center)
                                .offset(y: -35)
                        }
                    
                    VStack(spacing: 16) {
                        Spacer()
                        Text("Design Your Dish✨").font(.title2.weight(.bold)).foregroundStyle(.white)
                        Text("You can enter your dish name here")
                            .font(.headline)
                            .foregroundStyle(.white.opacity(0.9))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                            .padding(.bottom, 480)
                    }
                    .allowsHitTesting(false)
                    
                    Color.clear
                        .contentShape(Rectangle())
                        .onTapGesture {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            withAnimation(.easeInOut(duration: 0.4)) {
                                tutorialStep = 2
                            }
                        }
                }
                .transition(.opacity)
                
            } else if tutorialStep == 2 {
                ZStack {
                    Color.black.opacity(0.7)
                        .ignoresSafeArea()
                        .reverseMask {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .frame(height: 32)
                                .padding(.horizontal, 175)
                                .frame(maxHeight: .infinity, alignment: .bottom)
                                .offset(y: -295)
                        }
                    
                    VStack(spacing: 16) {
                        Spacer()
                        Text("Choose Your Cook Method").font(.title2.weight(.bold)).foregroundStyle(.white)
                        Text("You can chose your cook method from here")
                            .font(.headline)
                            .foregroundStyle(.white.opacity(0.9))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                            .padding(.bottom, 480)
                    }
                    .allowsHitTesting(false)
                    
                    Color.clear
                        .contentShape(Rectangle())
                        .onTapGesture {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            withAnimation(.easeOut(duration: 0.4)) {
                                hasSeenCreatorTutorial = true
                            }
                        }
                }
                .transition(.opacity)
            }
        }
    }
    
    /// I built this specific tutorial just for the ingredients page
    @ViewBuilder
    private var step2SpotlightTutorial: some View {
        ZStack {
            Color.black.opacity(0.7)
                .ignoresSafeArea()
                .reverseMask {
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .frame(height: 380)
                        .padding(.horizontal, 16)
                        .frame(maxHeight: .infinity, alignment: .center)
                        .offset(y: -55)
                }
            
            VStack(spacing: 16) {
                Spacer()
                
                Text("Pick Your Ingredients 🥦").font(.title2.weight(.bold)).foregroundStyle(.white)
                Text("Tap on any category folder to open it and select the fresh items you need")
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                    .padding(.bottom, 120)
            }
            .allowsHitTesting(false)
            
            Color.clear
                .contentShape(Rectangle())
                .onTapGesture {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeOut(duration: 0.4)) {
                        hasSeenStep2Tutorial = true
                    }
                }
        }
    }
    
    /// I updated this screen to also teach the user about the pre seasoning toggle
        @ViewBuilder
        private var step3SpotlightTutorial: some View {
            ZStack {
                Color.black.opacity(0.7)
                    .ignoresSafeArea()
                    .reverseMask {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .frame(height: 200)
                            .padding(.horizontal, 16)
                            .frame(maxHeight: .infinity, alignment: .center)
                            .offset(y: -155)
                    }
                
                VStack(spacing: 16) {
                    Spacer()
                    
                    Text("Prep Your Food 🔪").font(.title2.weight(.bold)).foregroundStyle(.white)
                    Text("Choose exactly how you want to chop slice or smash each ingredient. \n Also make sure to toggle the pre seasoning switch if that item needs to be marinated before cooking.")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.9))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                        .padding(.bottom, 280)
                }
                .allowsHitTesting(false)
                
                Color.clear
                    .contentShape(Rectangle())
                    .onTapGesture {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        withAnimation(.easeOut(duration: 0.4)) {
                            hasSeenStep3Tutorial = true
                        }
                    }
            }
        }
    
    /// I built this screen to highlight the note taking area
    @ViewBuilder
    private var step4SpotlightTutorial: some View {
        ZStack {
            Color.black.opacity(0.7)
                .ignoresSafeArea()
                .reverseMask {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .frame(height: 55)
                        .padding(.horizontal, 15)
                        .frame(maxHeight: .infinity, alignment: .top)
                        .padding(.top, 125)
                }
            
            VStack(spacing: 16) {
                Text("Chef Notes 📝").font(.title2.weight(.bold)).foregroundStyle(.white)
                Text("Type any special warnings, techniques, or reminders for yourself right here.")
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                
                Spacer()
            }
            .padding(.top, 260)
            .allowsHitTesting(false)
            
            Color.clear
                .contentShape(Rectangle())
                .onTapGesture {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeOut(duration: 0.4)) {
                        hasSeenStep4Tutorial = true
                    }
                }
        }
    }
    
    /// I created a two page tutorial here because scheduling is very important
    @ViewBuilder
    private var step5SpotlightTutorial: some View {
        ZStack {
            if step5TutorialPage == 1 {
                ZStack {
                    Color.black.opacity(0.7)
                        .ignoresSafeArea()
                        .reverseMask {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .frame(height: 110)
                                .padding(.horizontal, 16)
                                .frame(maxHeight: .infinity, alignment: .bottom)
                                .offset(y: -140)
                        }
                    
                    VStack(spacing: 16) {
                        Spacer()
                        Text("Cooking Order ⏱️").font(.title2.weight(.bold)).foregroundStyle(.white)
                        Text("Drag your ingredients into the pot in the exact order you want to cook them. If something needs to cook first put it in a batch by itself.")
                            .font(.headline)
                            .foregroundStyle(.white.opacity(0.9))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                            .padding(.bottom, 280)
                    }
                    .allowsHitTesting(false)
                    
                    Color.clear
                        .contentShape(Rectangle())
                        .onTapGesture {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            withAnimation(.easeInOut(duration: 0.4)) {
                                step5TutorialPage = 2
                            }
                        }
                }
                .transition(.opacity)
                
            } else if step5TutorialPage == 2 {
                ZStack {
                    Color.black.opacity(0.7)
                        .ignoresSafeArea()
                        .reverseMask {
                            Circle()
                                .frame(height: 170)
                                .padding(.horizontal, 16)
                                .frame(maxHeight: .infinity, alignment: .center)
                                .offset(y: -119)
                        }
                    
                    VStack(spacing: 16) {
                        Spacer()
                        Text("Time It Perfectly").font(.title2.weight(.bold)).foregroundStyle(.white)
                        Text("Set how long this batch cooks. If you are just tossing items in without waiting slide the timer to zero minutes")
                            .font(.headline)
                            .foregroundStyle(.white.opacity(0.9))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                            .padding(.bottom, 300)
                    }
                    .allowsHitTesting(false)
                    
                    Color.clear
                        .contentShape(Rectangle())
                        .onTapGesture {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            withAnimation(.easeOut(duration: 0.4)) {
                                hasSeenStep5Tutorial = true
                            }
                        }
                }
                .transition(.opacity)
            }
        }
    }
    
    /// I updated this final tutorial to explain how the Before box connects to the pre seasoning toggle
    @ViewBuilder
    private var step6SpotlightTutorial: some View {
        ZStack {
            Color.black.opacity(0.7)
                .ignoresSafeArea()
                .reverseMask {
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .frame(height: 180)
                        .padding(.horizontal, 16)
                        .frame(maxHeight: .infinity, alignment: .bottom)
                        .offset(y: -90)
                }
            
            VStack(spacing: 16) {
                Spacer()
                Text("Flavor Stages 🧂").font(.title2.weight(.bold)).foregroundStyle(.white)
                Text("Drag your spices into the Before, During, or After boxes. Anything dropped in the Before box will be used to marinate the ingredients you checked for pre seasoning earlier.")
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                    .padding(.bottom, 300)
            }
            .allowsHitTesting(false)
            
            Color.clear
                .contentShape(Rectangle())
                .onTapGesture {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeOut(duration: 0.4)) {
                        hasSeenStep6Tutorial = true
                    }
                }
        }
    }
    
    /// This cleans the slate so you can make another recipe immediately
    func resetCreator() {
        withAnimation {
            currentStep = 0
            customName = ""
            selectedIngredients.removeAll()
            itemCutStyles.removeAll()
            itemPreSeasoning.removeAll()
            cookPhases.removeAll()
            stagedIngredients.removeAll()
            phaseTime = 5.0
            seasoningsBefore.removeAll()
            seasoningsDuring.removeAll()
            seasoningsAfter.removeAll()
            customNotes.removeAll()
            selectedCategory = nil
        }
    }
}
