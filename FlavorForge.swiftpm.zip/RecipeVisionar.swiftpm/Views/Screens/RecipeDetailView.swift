import SwiftUI

/// MARK Main Detail Container
/// I created this main structure view to manage all the different cooking steps
/// This view acts as the parent container that holds the swipeable pages
/// I designed it this way so the user can easily swipe left and right through the recipe
struct RecipeDetailView: View {
    
    /// I bring in the recipe manager from the environment so I can access my global data
    @EnvironmentObject var manager: RecipeManager
    
    /// I store the specific recipe that the user tapped on right here
    let recipe: Recipe
    
    /// I use this state variable to keep track of exactly which page the user is currently viewing
    @State private var currentStep = 0
    
    /// I build the main visual interface inside this body variable
    var body: some View {
        ZStack {
            /// I use the standard native system background color here to make it feel like a real Apple app
            Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
            
            /// I use a TabView to create the smooth swiping experience between the different cooking stages
            TabView(selection: $currentStep) {
                
                /// I show the ingredient gathering step on the very first page
                PrepStepView(recipe: recipe).tag(0)
                
                /// I show the chopping and smashing interactive game on the second page
                ChopStepView(recipe: recipe).tag(1)
                
                /// I check if the chef wrote any special notes and I only show this page if notes actually exist
                if let notes = recipe.notes, !notes.isEmpty {
                    NoteStepView(recipe: recipe).tag(2)
                }
                
                /// I show the main cooking timeline here and I use a dynamic tag number depending on if the notes page exists
                CookStepView(recipe: recipe).tag(cookTag)
                
                /// I show the final plating page at the very end
                FinishStepView(recipe: recipe).tag(finishTag)
            }
            /// I tell the tab view to behave like a paging scroll view
            .tabViewStyle(.page(indexDisplayMode: .always))
            /// I force the page dots at the bottom to always show their background so they are easy to see
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
        /// I set the navigation title to the name of the dish
        .navigationTitle(recipe.name)
        /// I make the title small and inline to save screen space
        .navigationBarTitleDisplayMode(.inline)
    }
    
    /// I wrote this small helper variable to quickly check if the recipe has any valid notes
    private var hasNotes: Bool {
        if let notes = recipe.notes { return !notes.isEmpty }
        return false
    }
    
    /// I dynamically calculate the page number for the cook step because the notes page might push it over by one
    private var cookTag: Int   { hasNotes ? 3 : 2 }
    
    /// I dynamically calculate the page number for the final finish step
    private var finishTag: Int { hasNotes ? 4 : 3 }
}
