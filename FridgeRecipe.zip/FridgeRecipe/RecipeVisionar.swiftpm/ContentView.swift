import SwiftUI

struct ContentView: View {
    @StateObject private var manager = RecipeManager()
    
    var body: some View {
        TabView {
            CookBoxView()
                .tabItem { Label("Cook Box", systemImage: "frying.pan") }
            
            RecipeCreatorView()
                .tabItem { Label("Create", systemImage: "wand.and.stars") }
            
            // NEW: The My Recipes Tab!
            MyRecipesView()
                .tabItem { Label("My Recipes", systemImage: "book.closed") }
        }
        .tint(.orange)
        .environmentObject(manager)
    }
}
