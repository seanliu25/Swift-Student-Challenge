import SwiftUI

// 1. Data Model for Ingredients
struct IngredientItem: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let emoji: String
    let color: Color
}

struct ContentView: View {
    // 2. Setup Data with Emojis and specific "Liquid" colors
    let ingredients = [
        IngredientItem(name: "Tomato", emoji: "🍅", color: .red),
        IngredientItem(name: "Potato", emoji: "🥔", color: .brown),
        IngredientItem(name: "Egg", emoji: "🥚", color: .yellow),
        IngredientItem(name: "Carrot", emoji: "🥕", color: .orange),
        IngredientItem(name: "Cheese", emoji: "🧀", color: .yellow),
        IngredientItem(name: "Onion", emoji: "🧅", color: .purple)
    ]
    
    @State private var selectedIngredient: IngredientItem? = nil
    @State private var showDish: Bool = false
    @State private var dishName: String = ""
    
    var body: some View {
        // 1. Wrap everything in a NavigationStack
        NavigationStack {
            ZStack {
                Color.white.ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        
                        VStack(spacing: 5) {
                            Text("RecipeVisionar")
                                .font(.system(size: 34, weight: .heavy, design: .rounded))
                                .foregroundColor(.black)
                            
                            Text("What's in your kitchen?")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .padding(.top, 20)
                        
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 20)], spacing: 25) {
                            ForEach(ingredients) { item in
                                LiquidEmojiButton(
                                    item: item,
                                    isSelected: selectedIngredient == item,
                                    action: {
                                        withAnimation(.spring(response: 0.5, dampingFraction: 0.6, blendDuration: 0)) {
                                            selectedIngredient = item
                                            pickDish(for: item.name)
                                        }
                                    }
                                )
                            }
                        }
                        .padding(25)
                        
                        if showDish, let currentItem = selectedIngredient {
                            // Now we pass BOTH the item and the dishName
                            NavigationLink(destination: RecipeDetailView(item: currentItem, dishName: dishName)) {
                                VStack(spacing: 15) {
                                    Text("👨‍🍳 Chef Recommends:")
                                        .font(.headline)
                                        .foregroundColor(.gray)
                                        .textCase(.uppercase)
                                    
                                    HStack {
                                        Text(dishName)
                                            .font(.system(size: 28, weight: .bold, design: .serif))
                                            .foregroundColor(.black)
                                            .multilineTextAlignment(.center)
                                        
                                        Image(systemName: "chevron.right")
                                            .foregroundColor(.orange)
                                            .font(.title2.bold())
                                    }
                                }
                                .padding(30)
                                .frame(maxWidth: .infinity)
                                .background(
                                    RoundedRectangle(cornerRadius: 30)
                                        .fill(.ultraThinMaterial)
                                        .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 10)
                                )
                                .padding(.horizontal)
                            }
                            .buttonStyle(PlainButtonStyle())
                            .transition(.scale.combined(with: .opacity))
                        }
                    }
                }
            }
        }
    }
    
    func pickDish(for ingredient: String) {
        let recipeMap: [String: String] = [
            "Tomato": "Tomato Basil Soup",
            "Potato": "Crispy Hash Browns",
            "Egg": "Cloud Omelette",
            "Carrot": "Roasted Honey Carrots",
            "Cheese": "Mac & Cheese Bites",
            "Onion": "French Onion Soup"
        ]
        dishName = recipeMap[ingredient] ?? "Mystery Dish"
        showDish = true
    }
}

// MARK: - Custom Liquid Button View
struct LiquidEmojiButton: View {
    let item: IngredientItem
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            ZStack {
                // The "Liquid" Blob Background
                if isSelected {
                    LiquidBlobShape()
                        .fill(item.color.opacity(0.2))
                        .frame(width: 140, height: 140)
                        .scaleEffect(1.1)
                } else {
                    Circle()
                        .fill(Color.gray.opacity(0.05))
                        .frame(width: 110, height: 110)
                }
                
                VStack(spacing: 8) {
                    Text(item.emoji)
                        .font(.system(size: 60))
                        .shadow(radius: isSelected ? 10 : 0)
                        .scaleEffect(isSelected ? 1.2 : 1.0)
                    
                    Text(item.name)
                        .font(.system(size: 16, weight: .medium, design: .rounded))
                        .foregroundColor(isSelected ? item.color : .gray)
                }
            }
        }
        .buttonStyle(ScaleButtonStyle())
    }
}

// MARK: - Custom Shapes & Styles
struct LiquidBlobShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let w = rect.width
        let h = rect.height
        
        path.move(to: CGPoint(x: w * 0.5, y: 0))
        path.addCurve(to: CGPoint(x: w, y: h * 0.5),
                      control1: CGPoint(x: w * 0.8, y: h * 0.1),
                      control2: CGPoint(x: w, y: h * 0.2))
        path.addCurve(to: CGPoint(x: w * 0.5, y: h),
                      control1: CGPoint(x: w, y: h * 0.8),
                      control2: CGPoint(x: w * 0.8, y: h))
        path.addCurve(to: CGPoint(x: 0, y: h * 0.5),
                      control1: CGPoint(x: w * 0.2, y: h),
                      control2: CGPoint(x: 0, y: h * 0.8))
        path.addCurve(to: CGPoint(x: w * 0.5, y: 0),
                      control1: CGPoint(x: 0, y: h * 0.2),
                      control2: CGPoint(x: w * 0.2, y: h * 0.1))
        
        return path
    }
}

struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}
