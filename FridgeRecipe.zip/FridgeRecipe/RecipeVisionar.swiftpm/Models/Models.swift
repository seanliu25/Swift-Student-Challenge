import SwiftUI

// MARK: - Ingredient Model
struct IngredientItem: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let emoji: String
    let color: Color
}

// MARK: - Recipe Model
// MARK: - Recipe Model
struct Recipe: Identifiable, Equatable, Codable, Hashable {
    var id = UUID()
    let name: String
    let requiredIngredients: Set<String>
    let method: String
    let emoji: String
    let cookTime: Int
}
