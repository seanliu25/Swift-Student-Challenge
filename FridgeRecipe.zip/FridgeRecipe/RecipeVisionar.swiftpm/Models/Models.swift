import SwiftUI

// A specific rule set for how to prep a single ingredient
//struct IngredientPrep: Codable, Hashable, Equatable {
//    var name: String
//    var cutStyle: String
//    var preSeason: Bool
//}

// MARK: - Ingredient Model
struct IngredientItem: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let emoji: String
    let color: Color
}

// MARK: - Recipe Model
struct Recipe: Identifiable, Equatable, Codable, Hashable {
    var id = UUID()
    let name: String
    let requiredIngredients: Set<String>
    let method: String
    let emoji: String
    let cookTime: Int
    
//    Season:
    var seasoningsBefore: [String] = []
    var seasoningsDuring: [String] = []
    var seasoningsAfter: [String] = []
    
//  Food cut styel: Made it optional for user to chose to add or not
    var cutStyle: String?
    
//    var ingredientPreps: [IngredientPrep]?
}
