import SwiftUI

struct RecipeDetailView: View {
    // We now pass the full item to get its color and emoji!
    let item: IngredientItem
    let dishName: String
    
    @State private var currentStep = 0
    
    var body: some View {
        ZStack {
            item.color.opacity(0.1).ignoresSafeArea() // Soft background color based on ingredient
            
            // This creates the horizontal paging effect
            TabView(selection: $currentStep) {
                
                // STEP 1: Preparation
                PrepStepView(item: item)
                    .tag(0)
                
                // STEP 2: Chopping Animation
                ChopStepView(item: item)
                    .tag(1)
                
                // STEP 3: Cooking Animation
                CookStepView(item: item)
                    .tag(2)
                
                // STEP 4: Finished Dish
                FinishStepView(dishName: dishName)
                    .tag(3)
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
        .navigationTitle(dishName)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Step 1: Preparation
struct PrepStepView: View {
    let item: IngredientItem
    
    @State private var showItems = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Step 1: Gather Ingredients")
                .font(.title2.bold())
            
            HStack(spacing: 20) {
                IngredientBubble(emoji: item.emoji, delay: 0.1, show: showItems)
                Text("+").font(.title).foregroundColor(.gray)
                IngredientBubble(emoji: "🧂", delay: 0.3, show: showItems)
                Text("+").font(.title).foregroundColor(.gray)
                IngredientBubble(emoji: "🧄", delay: 0.5, show: showItems)
            }
            
            Text("Swipe to start prepping! 👉")
                .foregroundColor(.gray)
                .padding(.top, 40)
        }
        .onAppear {
            showItems = true
        }
    }
}

struct IngredientBubble: View {
    let emoji: String
    let delay: Double
    let show: Bool
    
    var body: some View {
        Text(emoji)
            .font(.system(size: 60))
            .padding(20)
            .background(Circle().fill(Color.white).shadow(radius: 5))
            .scaleEffect(show ? 1 : 0.001)
            .animation(.spring(response: 0.5, dampingFraction: 0.6).delay(delay), value: show)
    }
}

// MARK: - Step 2: Chopping Animation
struct ChopStepView: View {
    let item: IngredientItem
    @State private var isChopping = false
    
    var body: some View {
        VStack(spacing: 40) {
            Text("Step 2: Chop the \(item.name)")
                .font(.title2.bold())
            
            ZStack {
                // The Ingredient (Splits apart slightly when chopped)
                HStack(spacing: isChopping ? 15 : -40) {
                    Text(item.emoji).font(.system(size: 80))
                        .clipShape(Rectangle().offset(x: -20)) // Left half
                    Text(item.emoji).font(.system(size: 80))
                        .clipShape(Rectangle().offset(x: 20)) // Right half
                }
                .offset(y: 40)
                
                // The Knife
                Text("🔪")
                    .font(.system(size: 100))
                    .rotationEffect(.degrees(isChopping ? -20 : 20))
                    .offset(x: 20, y: isChopping ? 20 : -50)
            }
            .frame(height: 200)
            
            Text(isChopping ? "Chop chop chop!" : "Ready...")
                .font(.headline)
                .foregroundColor(item.color)
        }
        .onAppear {
            // Creates a continuous looping animation
            withAnimation(.easeInOut(duration: 0.3).repeatForever(autoreverses: true)) {
                isChopping.toggle()
            }
        }
    }
}

// MARK: - Step 3: Cooking Animation
struct CookStepView: View {
    let item: IngredientItem
    @State private var isCooking = false
    
    var body: some View {
        VStack(spacing: 40) {
            Text("Step 3: Into the pan!")
                .font(.title2.bold())
            
            ZStack {
                // Fire
                Text("🔥")
                    .font(.system(size: 100))
                    .offset(y: 60)
                    .scaleEffect(isCooking ? 1.2 : 0.8)
                    .opacity(isCooking ? 1.0 : 0.7)
                
                // Pan
                Text("🍳")
                    .font(.system(size: 140))
                
                // Ingredient tossing in the pan
                Text(item.emoji)
                    .font(.system(size: 50))
                    .offset(x: isCooking ? -20 : 20, y: isCooking ? -30 : 0)
                    .rotationEffect(.degrees(isCooking ? -45 : 45))
            }
            .frame(height: 250)
            
            VStack {
                Text("Cooking Time: 5 mins")
                    .font(.headline)
                ProgressView()
                    .progressViewStyle(.circular)
                    .scaleEffect(1.5)
                    .padding(.top, 10)
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                isCooking.toggle()
            }
        }
    }
}

// MARK: - Step 4: Finished Dish
struct FinishStepView: View {
    let dishName: String
    @State private var isPlated = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Tada! 🎉")
                .font(.system(size: 40, weight: .heavy, design: .rounded))
            
            Text("🍲")
                .font(.system(size: 150))
                .scaleEffect(isPlated ? 1.0 : 0.5)
                .rotationEffect(.degrees(isPlated ? 0 : -180))
                .opacity(isPlated ? 1 : 0)
            
            Text(dishName)
                .font(.title.bold())
                .foregroundColor(.black)
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.5)) {
                isPlated = true
            }
        }
    }
}
