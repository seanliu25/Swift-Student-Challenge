//
//  RecipeVisionarApp.swift
//  RecipeVisionar
//
//  Created by Shangwei Liu on 2/22/26.
//

import SwiftUI

@main
struct RecipeVisionarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
