import SwiftUI

class RecipeManager: ObservableObject {
    @Published var potIngredients: [IngredientItem] = []
//    hold an array of recipes:
    @Published var suggestedRecipes: [Recipe] = []
    // We start empty and load from defaults
    @Published var recipeDatabase: [Recipe] = []
    
    // A signal to reset navigation back to the main screen
    @Published var resetNavigation = false
    
    // The base recipes that come with the app
    let defaultRecipes: [Recipe] = [
        // The Classics
        Recipe(name: "Shakshuka", requiredIngredients: ["Tomato", "Egg", "Onion"], method: "Fry", emoji: "🍳", cookTime: 6),
        Recipe(name: "Potato Omelette", requiredIngredients: ["Potato", "Egg", "Onion"], method: "Fry", emoji: "🥘", cookTime: 8),
        Recipe(name: "Veggie Stew", requiredIngredients: ["Tomato", "Carrot", "Potato", "Onion"], method: "Boil", emoji: "🍲", cookTime: 12),
        Recipe(name: "Tomato Soup", requiredIngredients: ["Tomato"], method: "Boil", emoji: "🥣", cookTime: 10),

        Recipe(name: "Cheeseburger", requiredIngredients: ["Beef", "Cheese", "Bread", "Tomato", "Onion"], method: "Fry", emoji: "🍔", cookTime: 10),
        Recipe(name: "Spaghetti Bolognese", requiredIngredients: ["Pasta", "Beef", "Tomato", "Garlic"], method: "Boil", emoji: "🍝", cookTime: 15),
        Recipe(name: "Grilled Cheese", requiredIngredients: ["Bread", "Cheese"], method: "Fry", emoji: "🥪", cookTime: 5),
        Recipe(name: "BLT Sandwich", requiredIngredients: ["Bacon", "Bread", "Tomato"], method: "Fry", emoji: "🥪", cookTime: 6),
        Recipe(name: "Chicken Soup", requiredIngredients: ["Chicken", "Carrot", "Onion", "Garlic"], method: "Boil", emoji: "🍜", cookTime: 20),
        Recipe(name: "Fried Rice", requiredIngredients: ["Rice", "Egg", "Carrot", "Onion"], method: "Fry", emoji: "🍛", cookTime: 12),
        Recipe(name: "Mushroom Risotto", requiredIngredients: ["Rice", "Mushroom", "Cheese", "Garlic"], method: "Boil", emoji: "🥘", cookTime: 25),
        Recipe(name: "Steak & Mash", requiredIngredients: ["Beef", "Potato", "Garlic"], method: "Fry", emoji: "🥩", cookTime: 15),
        Recipe(name: "Chicken Parmesan", requiredIngredients: ["Chicken", "Tomato", "Cheese"], method: "Bake", emoji: "🍗", cookTime: 25)
    ]
    
    let availableIngredients: [IngredientItem] = [
        // Veggies & Basics
        IngredientItem(name: "Tomato", emoji: "🍅", color: .red),
        IngredientItem(name: "Potato", emoji: "🥔", color: .brown),
        IngredientItem(name: "Carrot", emoji: "🥕", color: .orange),
        IngredientItem(name: "Onion", emoji: "🧅", color: .purple),
        IngredientItem(name: "Garlic", emoji: "🧄", color: .gray),
        IngredientItem(name: "Mushroom", emoji: "🍄", color: .brown),
        
        // Dairy & Eggs
        IngredientItem(name: "Egg", emoji: "🥚", color: .yellow),
        IngredientItem(name: "Cheese", emoji: "🧀", color: .yellow),
        
        // Carbs
        IngredientItem(name: "Rice", emoji: "🍚", color: .white),
        IngredientItem(name: "Pasta", emoji: "🍝", color: .yellow),
        IngredientItem(name: "Bread", emoji: "🍞", color: .brown),
        
        // Meats
        IngredientItem(name: "Beef", emoji: "🥩", color: .red),
        IngredientItem(name: "Chicken", emoji: "🍗", color: .orange),
        IngredientItem(name: "Bacon", emoji: "🥓", color: .pink)
    ]
    
    // MARK: - Initialization (Loads data when app starts)
    init() {
        loadFromDevice()
    }
    
    // MARK: - App Logic
    func dropIngredients(names: [String]) {
        for itemName in names {
            if let found = availableIngredients.first(where: { $0.name == itemName }), !potIngredients.contains(found) {
                potIngredients.append(found)
            }
        }
    }
    
    func clearPot() {
            potIngredients.removeAll()
            // Clear the array
            suggestedRecipes.removeAll()
        }
    
    func findRecipe() -> Bool {
        let selectedNames = Set(potIngredients.map { $0.name })
        
        // Use .filter to find ALL recipes that match:
        let matches = recipeDatabase.filter { $0.requiredIngredients.isSubset(of: selectedNames) }
        
        if !matches.isEmpty {
            // We found at least one match!
            suggestedRecipes = matches
            return true
        }
        else {
            // No matches found
            suggestedRecipes = []
            return false
        }
    }
    
    // MARK: - Database Logic (Permanent Storage)
    func saveCustomRecipe(name: String, method: String, requiredIngredients: Set<String>, cookTime: Int) {
        let newRecipe = Recipe(
            name: name,
            requiredIngredients: requiredIngredients,
            method: method,
            emoji: "✨",
            cookTime: cookTime
        )
        
        recipeDatabase.append(newRecipe)
        saveToDevice() // Save permanently whenever a new recipe is added!
    }
    
    // Deletes a recipe and permanently saves the updated list to the device
    func deleteRecipe(at offsets: IndexSet) {
        recipeDatabase.remove(atOffsets: offsets)
        saveToDevice()
    }
    
    // Translates the recipes to JSON and saves them to the iPhone
    private func saveToDevice() {
        if let encoded = try? JSONEncoder().encode(recipeDatabase) {
            UserDefaults.standard.set(encoded, forKey: "SavedRecipes")
        }
    }
    
    // Grabs the JSON from the iPhone and translates it back into Recipes
    private func loadFromDevice() {
        if let savedData = UserDefaults.standard.data(forKey: "SavedRecipes"),
           let decodedRecipes = try? JSONDecoder().decode([Recipe].self, from: savedData) {
            recipeDatabase = decodedRecipes
        }
        else {
            // If it's the user's very first time opening the app, give them the default recipes!
            recipeDatabase = defaultRecipes
        }
    }
}
