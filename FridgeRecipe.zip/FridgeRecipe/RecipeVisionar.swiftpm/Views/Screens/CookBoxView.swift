import SwiftUI

struct CookBoxView: View {
    @EnvironmentObject var manager: RecipeManager
    
    @State private var showNoMatchAlert = false
    @State private var showMatchedRecipes = false
    
    // MARK: - Custom Drag State
    @State private var draggingItem: IngredientItem? = nil
    @State private var dragLocation: CGPoint = .zero
    @State private var isHoveringPot = false
    
    var body: some View {
        NavigationStack {
            GeometryReader { geo in
                ZStack {
                    Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                    
                    VStack(spacing: 15) {
                        Text("Drag Ingredients to the Pot!")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .padding(.top, 10)
                        
                        // MARK: - Scrollable Ingredients Box
                        ScrollView(.vertical, showsIndicators: false) {
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 20) {
                                ForEach(manager.availableIngredients) { item in
                                    VStack {
                                        Text(item.emoji)
                                            .font(.system(size: 50))
                                            .frame(width: 80, height: 80)
                                            .background(Circle().fill(Color.white).shadow(radius: 5))
                                            .opacity(draggingItem == item ? 0.3 : 1.0)
                                        
                                            // Added minimumDistance so users can still scroll the list!
                                            .gesture(
                                                DragGesture(minimumDistance: 5, coordinateSpace: .global)
                                                    .onChanged { value in
                                                        draggingItem = item
                                                        dragLocation = value.location
                                                        isHoveringPot = value.location.y > (geo.size.height * 0.65)
                                                    }
                                                    .onEnded { value in
                                                        if isHoveringPot {
                                                            withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                                                                manager.dropIngredients(names: [item.name])
                                                            }
                                                        }
                                                        withAnimation(.easeInOut(duration: 0.2)) {
                                                            draggingItem = nil
                                                            isHoveringPot = false
                                                        }
                                                    }
                                            )
                                        
                                        Text(item.name).font(.caption).bold()
                                    }
                                }
                            }
                            .padding(.vertical, 15)
                        }
                        // This limits the box to the top 25% of the screen so the pot ALWAYS fits at the bottom
                        .frame(maxHeight: geo.size.height * 0.65)
                        // Adds a nice subtle background so it looks like a Box
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.white.opacity(0.5))
                                .shadow(color: .black.opacity(0.05), radius: 10, x: 0, y: 5)
                        )
                        .padding(.horizontal)
                        
                        Spacer()
                        
                        // MARK: - The Drop Zone (The Pot)
                        ZStack {
                            Circle()
                                .fill(isHoveringPot ? Color.green.opacity(0.3) : (manager.potIngredients.isEmpty ? Color.gray.opacity(0.2) : Color.orange.opacity(0.2)))
                                // I shrunk the pot slightly from 250 to 220 to give it better breathing room
                                .frame(width: 190, height: 190)
                                .overlay(Circle().stroke(isHoveringPot ? Color.green : Color.orange, style: StrokeStyle(lineWidth: 3, dash: [10])))
                                .scaleEffect(isHoveringPot ? 1.05 : 1.0)
                            
                            if manager.potIngredients.isEmpty {
                                Text("Drop Here\n🍲")
                                    .multilineTextAlignment(.center)
                                    .font(.title)
                                    .foregroundColor(.gray)
                            }
                            else {
                                ForEach(Array(manager.potIngredients.enumerated()), id: \.offset) { index, item in
                                    Text(item.emoji)
                                        .font(.system(size: 40))
                                        .offset(x: cos(Double(index) / Double(manager.potIngredients.count) * 2 * .pi) * 50,
                                                y: sin(Double(index) / Double(manager.potIngredients.count) * 2 * .pi) * 50)
                                        .transition(.scale.combined(with: .opacity))
                                }
                            }
                        }
                        
                        Spacer()
                        
                        // MARK: - Action Buttons
                        HStack {
                            Button("Clear Pot") {
                                withAnimation { manager.clearPot() }
                            }
                            .buttonStyle(.bordered)
                            .tint(.red)
                            .disabled(manager.potIngredients.isEmpty)
                            
                            Button("What can I make?") {
                                if manager.findRecipe() {
                                    showMatchedRecipes = true
                                }
                                else {
                                    showNoMatchAlert = true
                                }
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.orange)
                            .disabled(manager.potIngredients.isEmpty)
                        }
                        .padding(.bottom, 10)
                    }
                    
                    // MARK: - THE OVERLAY
                    if let draggingItem = draggingItem {
                        Text(draggingItem.emoji)
                            .font(.system(size: 60))
                            .shadow(color: .black.opacity(0.3), radius: 10, x: 0, y: 15)
                            .position(dragLocation)
                            .ignoresSafeArea()
                    }
                }
            }
//            Title:
            .navigationTitle("Select Ingredients")
            .navigationBarTitleDisplayMode(.inline)
//            Navigation:
            .navigationDestination(isPresented: $showMatchedRecipes) {
                MatchedRecipesView(recipes: manager.suggestedRecipes)
            }
            .alert("Chef's Surprise!", isPresented: $showNoMatchAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("We don't have a specific recipe for this combo, but it sounds like a creative experiment! Try cooking it!")
            }
        }
    }
}
