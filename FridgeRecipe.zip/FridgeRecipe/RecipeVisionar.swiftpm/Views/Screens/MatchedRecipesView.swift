import SwiftUI

struct MatchedRecipesView: View {
    @EnvironmentObject var manager: RecipeManager
    
    // This holds the list of recipes that matched the pot
    let recipes: [Recipe]
    
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
            
            // left/right swiping
            TabView {
                ForEach(recipes) { recipe in
                    VStack(spacing: 30) {
                        Spacer()
                        
                        // 1. The Giant Food Icon
                        Text(recipe.emoji)
                            .font(.system(size: 180))
                            .shadow(color: .black.opacity(0.2), radius: 15, x: 0, y: 15)
                        
                        // 2. The Dish Name
                        Text(recipe.name)
                            .font(.system(size: 40, weight: .heavy, design: .rounded))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Text("\(recipe.method) • \(recipe.cookTime) mins")
                            .font(.title3)
                            .foregroundColor(.gray)
                        
                        Spacer()
                        
                        // 3. The Link to the Detail Page
                        NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                            Text("How to cook this")
                                .font(.title2.bold())
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 18)
                                .background(Color.orange)
                                .cornerRadius(15)
                                .shadow(radius: 5)
                                .padding(.horizontal, 40)
                        }
                        .padding(.bottom, 60)
                    }
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            // Shows the dots at the bottom
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
        .navigationTitle("Matches Found!")
        .navigationBarTitleDisplayMode(.inline)
    }
}
