import SwiftUI

struct MyRecipesView: View {
    @EnvironmentObject var manager: RecipeManager
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                
                if manager.recipeDatabase.isEmpty {
                    VStack {
                        Text("No recipes yet! 🥺")
                            .font(.title2.bold())
                        Text("Go to the Create tab to make some magic.")
                            .foregroundColor(.gray)
                    }
                }
                else {
                    List {
                        // Loop through all saved recipes
                        ForEach(manager.recipeDatabase) { recipe in
                            NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                                HStack(spacing: 15) {
                                    Text(recipe.emoji)
                                        .font(.system(size: 40))
                                        .padding(10)
                                        .background(Circle().fill(Color.orange.opacity(0.2)))
                                    
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(recipe.name)
                                            .font(.headline)
                                        
                                        // Shows a summary of the ingredients
                                        Text(recipe.requiredIngredients.joined(separator: ", "))
                                            .font(.caption)
                                            .foregroundColor(.gray)
                                            .lineLimit(1)
                                    }
                                    
                                    Spacer()
                                    
                                    VStack(alignment: .trailing) {
                                        Text(recipe.method)
                                            .font(.caption.bold())
                                            .foregroundColor(.orange)
                                        Text("\(recipe.cookTime)m")
                                            .font(.caption2)
                                            .foregroundColor(.gray)
                                    }
                                }
                                .padding(.vertical, 5)
                            }
                        }
                        // Adding Swipe to Delete functionality
                        .onDelete(perform: manager.deleteRecipe)
                    }
                    .scrollContentBackground(.hidden) // Makes the list blend with the background color
                }
            }
            .navigationTitle("My Recipes")
        }
    }
    
    func deleteRecipe(at offsets: IndexSet) {
        manager.recipeDatabase.remove(atOffsets: offsets)
        // Note: You would also call manager.saveToDevice() here if you have that setup!
    }
}
