import SwiftUI

struct RecipeCreatorView: View {
    @EnvironmentObject var manager: RecipeManager
    
    // MARK: - Wizard State
    @State private var currentStep = 0
    @State private var customName = ""
    @State private var selectedMethod = "Boil"

//    User style chose:
    @State private var selectedIngredients: Set<String> = []
    @State private var selectedCutStyle = "Chop"
    let cutStyles = ["Chop", "Dice", "Slice", "Mince", "Halve"]
    
    @State private var cookTime: Double = 5.0
    
    // MARK: - Seasoning State
    @State private var availableSeasonings = ["Salt 🧂", "Pepper 🌶️", "Garlic Powder 🧄", "Honey Sauce 🍯", "Soy Sauce 🫙", "Olive Oil 🫒"]
    @State private var customSeasoningText = ""
    @State private var seasoningsBefore: [String] = []
    @State private var seasoningsDuring: [String] = []
    @State private var seasoningsAfter: [String] = []
    
    // MARK: - Custom Drag State
    @State private var draggingSeasoning: String? = nil
    @State private var dragLocation: CGPoint = .zero
    @State private var hoveredZone: String? = nil // Tracks "Before", "During", or "After"
    
    // MARK: - Save Alert State
    @State private var showSavedAlert = false
    
    let methods = ["Boil": "🍲", "Fry": "🍳", "Bake": "🎛️", "steam": "♨️", "grill": "🔥"]
    
    var body: some View {
        NavigationStack {
            // NEW: Wrapped everything in GeometryReader and ZStack for the Ghost Overlay!
            GeometryReader { geo in
                ZStack {
                    Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                    
                    VStack {
                        // MARK: - Progress Bar
                        ProgressView(value: Double(currentStep + 1), total: 5.0)
                            .tint(.orange)
                            .padding()
                        
                        // MARK: - Wizard Steps
                        TabView(selection: $currentStep) {
                            
                            // STEP 1: Name & Method
                            VStack(spacing: 30) {
                                Text("Step 1: The Basics").font(.title.bold())
                                
                                TextField("Name your masterpiece...", text: $customName)
                                    .textFieldStyle(.roundedBorder)
                                    .padding(.horizontal)
                                
                                Text("How will you cook it?")
                                    .font(.headline)
                                    .foregroundColor(.gray)
                                
                                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 20) {
                                    ForEach(methods.keys.sorted(), id: \.self) { method in
                                        Button {
                                            withAnimation { selectedMethod = method }
                                        } label: {
                                            VStack {
                                                Text(methods[method] ?? "🍳").font(.system(size: 50))
                                                Text(method).font(.headline)
                                            }
                                            .padding()
                                            .frame(maxWidth: .infinity)
                                            .background(RoundedRectangle(cornerRadius: 15).fill(selectedMethod == method ? Color.orange.opacity(0.3) : Color.white))
                                            .overlay(RoundedRectangle(cornerRadius: 15).stroke(selectedMethod == method ? Color.orange : Color.gray.opacity(0.2), lineWidth: 2))
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                                .padding(.horizontal)
                            }
                            .tag(0)
                            
                            // STEP 2: Ingredients
                            VStack(spacing: 15) {
                                Text("Step 2: Ingredients").font(.title.bold())
//                                Style chose
                                Text("How should we prep them?").font(.headline).foregroundColor(.gray)
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 10) {
                                        ForEach(cutStyles, id: \.self) { style in
                                            Text(style)
                                                .font(.subheadline.bold())
                                                .padding(.vertical, 8)
                                                .padding(.horizontal, 16)
                                                .background(Capsule().fill(selectedCutStyle == style ? Color.orange.opacity(0.3) : Color.white).shadow(radius: 2))
                                                .overlay(Capsule().stroke(selectedCutStyle == style ? Color.orange : Color.clear, lineWidth: 2))
                                                .onTapGesture { withAnimation { selectedCutStyle = style } }
                                        }
                                    }
                                    .padding(.horizontal)
                                    .padding(.bottom, 5)
                                }
//                                Recipe:
                                Text("Tap to add to your recipe!")
                                    .foregroundColor(.gray)
                                    .padding(.top, 5)
                                ScrollView(.vertical, showsIndicators: false) {
                                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 20) {
                                        ForEach(manager.availableIngredients) { item in
                                            let isSelected = selectedIngredients.contains(item.name)
                                            Button {
                                                withAnimation(.spring()) {
                                                    if isSelected { selectedIngredients.remove(item.name) }
                                                    else { selectedIngredients.insert(item.name) }
                                                }
                                            }
                                            
                                            label: {
                                                VStack {
                                                    Text(item.emoji)
                                                        .font(.system(size: 40))
                                                        .padding()
                                                        .background(Circle().fill(isSelected ? Color.green.opacity(0.3) : Color.white).shadow(radius: 5))
                                                        .overlay(Circle().stroke(isSelected ? Color.green : Color.clear, lineWidth: 3))
                                                        .scaleEffect(isSelected ? 1.1 : 1.0)
                                                    
                                                    Text(item.name)
                                                        .font(.caption).bold()
                                                        .foregroundColor(isSelected ? .green : .primary)
                                                }
                                            }
                                            .buttonStyle(.plain)
                                        }
                                    }
                                    .padding(.horizontal)
                                    .padding(.bottom, 20)
                                }
                            }
                            .tag(1)
                            
                            // STEP 3: Timing
                            VStack(spacing: 30) {
                                Text("Step 3: Cooking Time").font(.title.bold())
                                Text(methods[selectedMethod] ?? "🍳").font(.system(size: 80))
                                
                                Text("\(Int(cookTime)) Minutes")
                                    .font(.system(size: 40, weight: .heavy, design: .rounded))
                                    .foregroundColor(.orange)
                                
                                Slider(value: $cookTime, in: 1...60, step: 1)
                                    .tint(.orange)
                                    .padding(.horizontal, 40)
                            }
                            .tag(2)
                            
                            // STEP 4: Interactive Seasoning Drag & Drop (Vertical Style!)
                            VStack(spacing: 15) {
                                Text("Step 4: Flavor Stages").font(.title.bold())
                                Text("Drag seasonings down into the boxes!")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                
                                // Add Custom Seasoning Box
                                HStack {
                                    TextField("Custom sauce/spice...", text: $customSeasoningText)
                                        .textFieldStyle(.roundedBorder)
                                    Button("Add") {
                                        if !customSeasoningText.isEmpty {
                                            withAnimation { availableSeasonings.insert(customSeasoningText, at: 0) }
                                            customSeasoningText = ""
                                        }
                                    }
                                    .buttonStyle(.borderedProminent)
                                    .tint(.orange)
                                }
                                .padding(.horizontal)
                                
                                // MARK: - Reverted & Optimized Drag Logic
                                ScrollView(.vertical, showsIndicators: false) {
                                    // CHANGED: Using an "adaptive" grid creates natural gaps for your thumb to scroll!
                                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 110), spacing: 15)], spacing: 15) {
                                        ForEach(availableSeasonings, id: \.self) { seasoning in
                                            Text(seasoning)
                                                .font(.subheadline.bold())
                                                .padding(.vertical, 12)
                                                .padding(.horizontal, 15)
                                                // 🛠️ FIX: Removed .frame(maxWidth: .infinity) so they shrink to fit the text!
                                                .background(Capsule().fill(Color.white).shadow(radius: 2))
                                                .opacity(draggingSeasoning == seasoning ? 0.3 : 1.0)
                                                
                                                // REVERTED to the buttery smooth DragGesture from CookBox!
                                                .gesture(
                                                    DragGesture(minimumDistance: 10, coordinateSpace: .global)
                                                        .onChanged { value in
                                                            draggingSeasoning = seasoning
                                                            dragLocation = value.location
                                                            
                                                            // Calculate which box we are hovering over
                                                            if value.location.y > (geo.size.height * 0.55) {
                                                                let third = geo.size.width / 3
                                                                if value.location.x < third { hoveredZone = "Before" }
                                                                else if value.location.x < (third * 2) { hoveredZone = "During" }
                                                                else { hoveredZone = "After" }
                                                            } else {
                                                                hoveredZone = nil
                                                            }
                                                        }
                                                        .onEnded { value in
                                                            if let zone = hoveredZone {
                                                                withAnimation(.spring()) {
                                                                    if zone == "Before" && !seasoningsBefore.contains(seasoning) { seasoningsBefore.append(seasoning) }
                                                                    else if zone == "During" && !seasoningsDuring.contains(seasoning) { seasoningsDuring.append(seasoning) }
                                                                    else if zone == "After" && !seasoningsAfter.contains(seasoning) { seasoningsAfter.append(seasoning) }
                                                                }
                                                            }
                                                            
                                                            withAnimation(.easeInOut(duration: 0.2)) {
                                                                draggingSeasoning = nil
                                                                hoveredZone = nil
                                                            }
                                                        }
                                                )
                                        }
                                    }
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 15)
                                }
                                .frame(maxHeight: geo.size.height * 0.35)
                                .background(
                                    RoundedRectangle(cornerRadius: 20)
                                        .fill(Color.white.opacity(0.5))
                                        .shadow(color: .black.opacity(0.05), radius: 10, x: 0, y: 5)
                                )
                                .padding(.horizontal)
                                .frame(maxHeight: geo.size.height * 0.35)
                                .background(
                                    RoundedRectangle(cornerRadius: 20)
                                        .fill(Color.white.opacity(0.5))
                                        .shadow(color: .black.opacity(0.05), radius: 10, x: 0, y: 5)
                                )
                                .padding(.horizontal)
                                // Restricts the ingredients to the top so the drop zones fit at the bottom!
                                .frame(maxHeight: geo.size.height * 0.35)
                                .background(
                                    RoundedRectangle(cornerRadius: 20)
                                        .fill(Color.white.opacity(0.5))
                                        .shadow(color: .black.opacity(0.05), radius: 10, x: 0, y: 5)
                                )
                                .padding(.horizontal)
                                
                                Spacer()
                                
                                // The 3 Drop Zones permanently at the bottom
                                HStack(spacing: 10) {
                                    SeasoningDropZone(title: "Pre Seasoning", items: $seasoningsBefore, isHovered: hoveredZone == "Before")
                                    SeasoningDropZone(title: "During", items: $seasoningsDuring, isHovered: hoveredZone == "During")
                                    SeasoningDropZone(title: "Post Seasoning", items: $seasoningsAfter, isHovered: hoveredZone == "After")
                                }
                                .padding(.horizontal)
                                .padding(.bottom, 20)
                            }
                            .tag(3)
                            
                            // STEP 5: Review
                            VStack(spacing: 20) {
                                Text("Ready to Cook! 🎉").font(.largeTitle.bold())
                                
                                VStack(alignment: .leading, spacing: 10) {
                                    Text("📝 Recipe: \(customName.isEmpty ? "My Custom Dish" : customName)")
                                    Text("👨‍🍳 Method: \(selectedMethod) \(methods[selectedMethod] ?? "")")
                                    Text("🛒 Ingredients: \(selectedIngredients.isEmpty ? "None!" : selectedIngredients.joined(separator: ", "))")
                                    Text("⏱️ Time: \(Int(cookTime)) mins")
                                    Text("🧂 Before: \(seasoningsBefore.isEmpty ? "None" : seasoningsBefore.joined(separator: ", "))")
                                    Text("🧂 During: \(seasoningsDuring.isEmpty ? "None" : seasoningsDuring.joined(separator: ", "))")
                                    Text("🧂 After: \(seasoningsAfter.isEmpty ? "None" : seasoningsAfter.joined(separator: ", "))")
                                }
                                .font(.title3)
                                .padding()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(RoundedRectangle(cornerRadius: 15).fill(Color.orange.opacity(0.1)))
                                .padding()
                                
                                Button("Save & Cook!") {
                                    manager.saveCustomRecipe(
                                        name: customName.isEmpty ? "My Custom Dish" : customName,
                                        method: selectedMethod,
                                        requiredIngredients: selectedIngredients,
                                        cookTime: Int(cookTime),
                                        cutStyle: selectedCutStyle,
                                        before: seasoningsBefore,
                                        during: seasoningsDuring,
                                        after: seasoningsAfter
                                    )
                                    showSavedAlert = true
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.orange)
                                .controlSize(.large)
                                // We removed the .disabled modifier so the button doesn't freeze the state!
                            }
                            .tag(4)
                        }
                        .tabViewStyle(.page(indexDisplayMode: .never))
                        
                        // MARK: - Navigation Buttons
                        HStack {
                            if currentStep > 0 {
                                Button("Back") { withAnimation { currentStep -= 1 } }
                                    .buttonStyle(.bordered)
                            }
                            Spacer()
                            if currentStep < 4 {
                                Button("Next") { withAnimation { currentStep += 1 } }
                                    .buttonStyle(.borderedProminent)
                                    .tint(.orange)
                                    .disabled(currentStep == 1 && selectedIngredients.isEmpty)
                            }
                        }
                        .padding()
                    }
                    
                    // MARK: - THE GHOST OVERLAY
                    if let draggingItem = draggingSeasoning {
                        Text(draggingItem)
                            .padding(.vertical, 8)
                            .padding(.horizontal, 15)
                            .background(Capsule().fill(Color.white).shadow(radius: 10))
                            .position(dragLocation)
                            .ignoresSafeArea()
                    }
                }
            }
            .navigationTitle("Recipe Creator")
            // Replaced the frozen button with a clean success alert!
            .alert("Recipe Saved! 🧑‍🍳", isPresented: $showSavedAlert) {
                Button("Awesome!") {
                    resetCreator()
                }
            }
        }
    }
    
    // Centralized reset function
    func resetCreator() {
        withAnimation {
            currentStep = 0
            customName = ""
            selectedIngredients.removeAll()
            cookTime = 5.0
            seasoningsBefore.removeAll()
            seasoningsDuring.removeAll()
            seasoningsAfter.removeAll()
        }
    }
}

// MARK: - Helper View for Step 4 Drop Zones
struct SeasoningDropZone: View {
    let title: String
    @Binding var items: [String]
    var isHovered: Bool
    
    var body: some View {
        VStack {
            Text(title).font(.subheadline.bold()).padding(.top, 10)
            
            ScrollView {
                VStack(spacing: 10) {
                    ForEach(items, id: \.self) { item in
                        // CHANGED: Converted the Text into a Button with a delete action!
                        Button {
                            withAnimation(.spring()) {
                                // Removes the item from the array when tapped
                                items.removeAll(where: { $0 == item })
                            }
                        } label: {
                            HStack(spacing: 5) {
                                Text(item)
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.red.opacity(0.7))
                            }
                            .font(.caption)
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .background(Capsule().fill(Color.orange.opacity(0.2)))
                            .foregroundColor(.primary)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.bottom, 10)
                .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 180)
        .background(RoundedRectangle(cornerRadius: 15).fill(isHovered ? Color.green.opacity(0.2) : Color.white).shadow(radius: 2))
        .overlay(RoundedRectangle(cornerRadius: 15).stroke(isHovered ? Color.green : Color.clear, lineWidth: 3))
    }
}
