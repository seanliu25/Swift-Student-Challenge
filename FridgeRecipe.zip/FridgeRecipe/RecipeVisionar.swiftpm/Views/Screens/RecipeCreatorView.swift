import SwiftUI

struct RecipeCreatorView: View {
    @EnvironmentObject var manager: RecipeManager
    
    // State for the wizard steps
    @State private var currentStep = 0
    
    // State for the custom recipe data
    @State private var customName = ""
    @State private var selectedMethod = "Boil"
    // NEW: Tracks the ingredients the user taps for this recipe!
    @State private var selectedIngredients: Set<String> = []
    @State private var cookTime: Double = 5.0
    @State private var addGarlic = false
    @State private var addSalt = true
    
    let methods = ["Boil": "🍲", "Fry": "🍳", "Bake": "🎛️"]
    
    var body: some View {
        NavigationStack {
            VStack {
                // MARK: - Progress Bar
                // Updated total steps to 5.0
                ProgressView(value: Double(currentStep + 1), total: 5.0)
                    .tint(.orange)
                    .padding()
                
                // MARK: - Wizard Steps
                TabView(selection: $currentStep) {
                    
                    // STEP 1: Name & Method
                    VStack(spacing: 30) {
                        Text("Step 1: The Basics").font(.title.bold())
                        
                        TextField("Name your masterpiece...", text: $customName)
                            .textFieldStyle(.roundedBorder)
                            .padding(.horizontal)
                        
                        Text("How will you cook it?")
                            .font(.headline)
                            .foregroundColor(.gray)
                        
                        HStack(spacing: 20) {
                            ForEach(methods.keys.sorted(), id: \.self) { method in
                                Button {
                                    withAnimation { selectedMethod = method }
                                } label: {
                                    VStack {
                                        Text(methods[method]!).font(.system(size: 50))
                                        Text(method).font(.headline)
                                    }
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius: 15).fill(selectedMethod == method ? Color.orange.opacity(0.3) : Color.white))
                                    .overlay(RoundedRectangle(cornerRadius: 15).stroke(selectedMethod == method ? Color.orange : Color.gray.opacity(0.2), lineWidth: 2))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .tag(0)
                    
                    // NEW STEP 2: Ingredients
                    VStack(spacing: 20) {
                        Text("Step 2: Ingredients").font(.title.bold())
                        Text("Tap to add to your recipe!")
                            .foregroundColor(.gray)
                        
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 20) {
                            ForEach(manager.availableIngredients) { item in
                                let isSelected = selectedIngredients.contains(item.name)
                                
                                Button {
                                    withAnimation(.spring()) {
                                        if isSelected {
                                            selectedIngredients.remove(item.name)
                                        } else {
                                            selectedIngredients.insert(item.name)
                                        }
                                    }
                                } label: {
                                    VStack {
                                        Text(item.emoji)
                                            .font(.system(size: 40))
                                            .padding()
                                            .background(Circle().fill(isSelected ? Color.green.opacity(0.3) : Color.white).shadow(radius: 5))
                                            .overlay(Circle().stroke(isSelected ? Color.green : Color.clear, lineWidth: 3))
                                            .scaleEffect(isSelected ? 1.1 : 1.0)
                                        
                                        Text(item.name)
                                            .font(.caption)
                                            .bold()
                                            .foregroundColor(isSelected ? .green : .primary)
                                    }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal)
                    }
                    .tag(1)
                    
                    // STEP 3: Timing
                    VStack(spacing: 30) {
                        Text("Step 3: Cooking Time").font(.title.bold())
                        Text(methods[selectedMethod]!).font(.system(size: 80))
                        
                        Text("\(Int(cookTime)) Minutes")
                            .font(.system(size: 40, weight: .heavy, design: .rounded))
                            .foregroundColor(.orange)
                        
                        Slider(value: $cookTime, in: 1...60, step: 1)
                            .tint(.orange)
                            .padding(.horizontal, 40)
                    }
                    .tag(2)
                    
                    // STEP 4: Seasoning
                    VStack(spacing: 30) {
                        Text("Step 4: Flavor").font(.title.bold())
                        
                        Toggle(isOn: $addSalt) {
                            Label("Add Salt & Pepper 🧂", systemImage: "sparkles")
                        }
                        .padding().background(Color.white).cornerRadius(15).shadow(radius: 2).padding(.horizontal)
                        
                        Toggle(isOn: $addGarlic) {
                            Label("Add Garlic 🧄", systemImage: "flame")
                        }
                        .padding().background(Color.white).cornerRadius(15).shadow(radius: 2).padding(.horizontal)
                    }
                    .tag(3)
                    
                    // STEP 5: Review
                    VStack(spacing: 20) {
                        Text("Ready to Cook! 🎉").font(.largeTitle.bold())
                        
                        VStack(alignment: .leading, spacing: 10) {
                            Text("📝 Recipe: \(customName.isEmpty ? "My Custom Dish" : customName)")
                            Text("👨‍🍳 Method: \(selectedMethod) \(methods[selectedMethod]!)")
                            // Show the selected ingredients here!
                            Text("🛒 Ingredients: \(selectedIngredients.isEmpty ? "None!" : selectedIngredients.joined(separator: ", "))")
                            Text("⏱️ Time: \(Int(cookTime)) mins")
                            Text("🧂 Seasoning: \(addSalt ? "Yes" : "No"), 🧄 Garlic: \(addGarlic ? "Yes" : "No")")
                        }
                        .font(.title3)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(RoundedRectangle(cornerRadius: 15).fill(Color.orange.opacity(0.1)))
                        .padding()
                        
                        Button("Save & Cook!") {
                            // NO MORE HACKS! We use the exactly selected ingredients.
                            manager.saveCustomRecipe(
                                name: customName.isEmpty ? "My Custom Dish" : customName,
                                method: selectedMethod,
                                requiredIngredients: selectedIngredients, // <-- Using the new state!
                                cookTime: Int(cookTime)
                            )
                            
                            // Reset the wizard
                            withAnimation {
                                currentStep = 0
                                customName = ""
                                selectedIngredients.removeAll() // Reset selection
                                cookTime = 5.0
                                addSalt = true
                                addGarlic = false
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.orange)
                        .controlSize(.large)
                        // Don't let them save a recipe with zero ingredients!
                        .disabled(selectedIngredients.isEmpty)
                    }
                    .tag(4)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                
                // MARK: - Navigation Buttons
                HStack {
                    if currentStep > 0 {
                        Button("Back") { withAnimation { currentStep -= 1 } }
                            .buttonStyle(.bordered)
                    }
                    Spacer()
                    // Updated to 4 so they can navigate all 5 pages
                    if currentStep < 4 {
                        Button("Next") { withAnimation { currentStep += 1 } }
                            .buttonStyle(.borderedProminent)
                            .tint(.orange)
                            // Prevent going to next step if no ingredients are picked on Step 1
                            .disabled(currentStep == 1 && selectedIngredients.isEmpty)
                    }
                }
                .padding()
            }
            .navigationTitle("Recipe Creator")
            .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
        }
    }
}
