import SwiftUI
import AVFoundation

struct RecipeDetailView: View {
    @EnvironmentObject var manager: RecipeManager
    let recipe: Recipe
    
    @State private var currentStep = 0
    
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
            
            TabView(selection: $currentStep) {
                PrepStepView(recipe: recipe).tag(0)
                ChopStepView(recipe: recipe).tag(1)
                CookStepView(recipe: recipe).tag(2)
                FinishStepView(recipe: recipe).tag(3)
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
        .navigationTitle(recipe.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Step 1: Prep
struct PrepStepView: View {
    @EnvironmentObject var manager: RecipeManager
    let recipe: Recipe
    @State private var showItems = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Step 1: Gather Ingredients").font(.title2.bold())
            
            // Dynamically load the emojis for this specific recipe!
            HStack(spacing: 15) {
                let items = manager.availableIngredients.filter { recipe.requiredIngredients.contains($0.name) }
                
                ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                    IngredientBubble(emoji: item.emoji, delay: Double(index) * 0.2, show: showItems)
                }
            }
            
            Text("Swipe to prep! 👉").foregroundColor(.gray).padding(.top, 40)
        }
        .onAppear { showItems = true }
    }
}

struct IngredientBubble: View {
    let emoji: String; let delay: Double; let show: Bool
    var body: some View {
        Text(emoji).font(.system(size: 45)).padding(15)
            .background(Circle().fill(Color.white).shadow(radius: 5))
            .scaleEffect(show ? 1 : 0.001)
            .animation(.spring(response: 0.5, dampingFraction: 0.6).delay(delay), value: show)
    }
}

// MARK: - Step 2: Chop
struct ChopStepView: View {
    let recipe: Recipe
    @State private var isChopping = false
    
    var body: some View {
        VStack(spacing: 40) {
            Text("Step 2: Prep the ingredients").font(.title2.bold())
            
            ZStack {
                Text("🔪").font(.system(size: 100))
                    .rotationEffect(.degrees(isChopping ? -20 : 30))
                    .offset(x: 20, y: isChopping ? 20 : -50)
                
                Text("🧅").font(.system(size: 60))
                    .offset(x: -20, y: 40)
            }
            .frame(height: 200)
            
            Text(isChopping ? "Chop chop chop!" : "Ready...").font(.headline).foregroundColor(.orange)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 0.35).repeatForever(autoreverses: true)) { isChopping.toggle() }
        }
    }
}

// MARK: - Step 3: Cook with Timer
struct CookStepView: View {
    let recipe: Recipe
    @State private var isCooking = false
    @State private var timeRemaining: Int = 0
    @State private var isTimerRunning = false
    
    // We use this to track if the user has manually pressed "Start"
    @State private var hasStarted = false
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 40) {
            Text("Step 3: \(recipe.method) time!").font(.title2.bold())
            
            ZStack {
                if recipe.method == "Fry" {
                    Text("🔥").font(.system(size: 100)).offset(y: 60).scaleEffect(isCooking ? 1.2 : 0.8).opacity(isCooking ? 1.0 : 0.7)
                    Text("🍳").font(.system(size: 140))
                } else if recipe.method == "Boil" {
                    Text("🍲").font(.system(size: 140))
                    Text("🫧").font(.system(size: 60)).offset(y: isCooking ? -80 : 0).opacity(isCooking ? 0 : 1)
                } else {
                    Text("🎛️").font(.system(size: 140))
                    RoundedRectangle(cornerRadius: 10).fill(Color.orange.opacity(isCooking ? 0.6 : 0.2)).frame(width: 100, height: 60).offset(y: 20)
                }
            }
            .frame(height: 250)
            
            VStack {
                // If they haven't started yet, show the "Start" button
                if !hasStarted {
                    Button {
                        // START THE TIMER MANUALLY
                        hasStarted = true
                        isTimerRunning = true
                        withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) { isCooking.toggle() }
                    } label: {
                        Text("Start Timer")
                            .font(.title3.bold())
                            .foregroundColor(.white)
                            .padding(.vertical, 12)
                            .padding(.horizontal, 30)
                            .background(Color.orange)
                            .cornerRadius(10)
                    }
                    .transition(.scale.combined(with: .opacity))
                }
                // Once started, show the countdown
                else if timeRemaining > 0 {
                    Text(String(format: "%02d:%02d", timeRemaining / 60, timeRemaining % 60))
                        .font(.system(size: 40, weight: .bold, design: .monospaced))
                        .foregroundColor(.orange)
                        .transition(.scale.combined(with: .opacity))
                        .onTapGesture {
                            timeRemaining = 1
                        }
                }
                // When done, show the Done text and play the sound
                else {
                    Text("Done! Swipe 👉")
                        .font(.title2.bold())
                        .foregroundColor(.green)
                        .transition(.scale.combined(with: .opacity))
                        .onAppear {
                            AudioServicesPlaySystemSound(1022)
                            UINotificationFeedbackGenerator().notificationOccurred(.success)
                        }
                }
            }
            .frame(height: 60)
            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: hasStarted)
            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: timeRemaining > 0)
        }
        .onAppear {
            // We set the initial time, but DO NOT start it running!
            timeRemaining = recipe.cookTime * 60
        }
        .onReceive(timer) { _ in
            if isTimerRunning && timeRemaining > 0 {
                timeRemaining -= 1
            } else if timeRemaining == 0 {
                isTimerRunning = false
            }
        }
    }
}


// MARK: - Step 4: Finish
struct FinishStepView: View {
    // 1. Connect to the manager
    @EnvironmentObject var manager: RecipeManager
    // 2. Allows us to close this specific page
    @Environment(\.dismiss) var dismiss
    
    let recipe: Recipe
    @State private var isPlated = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Tada! 🎉").font(.system(size: 40, weight: .heavy, design: .rounded))
            
            Text(recipe.emoji)
                .font(.system(size: 150))
                .scaleEffect(isPlated ? 1.0 : 0.5)
                .opacity(isPlated ? 1 : 0)
            
            Text(recipe.name).font(.title.bold()).foregroundColor(.black)
            
            if isPlated {
                Button("Back to Kitchen") {
                    manager.resetNavigation = true // Signals the CookBox to pop to root
                    dismiss() // Closes this tutorial page
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .controlSize(.large)
                .padding(.top, 20)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.5)) { isPlated = true }
        }
    }
}
