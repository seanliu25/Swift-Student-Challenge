import SwiftUI
import AVFoundation

struct RecipeDetailView: View {
    @EnvironmentObject var manager: RecipeManager
    let recipe: Recipe
    
    @State private var currentStep = 0
    
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
            
            TabView(selection: $currentStep) {
                PrepStepView(recipe: recipe).tag(0)
                ChopStepView(recipe: recipe).tag(1)
                CookStepView(recipe: recipe).tag(2)
                FinishStepView(recipe: recipe).tag(3)
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
        .navigationTitle(recipe.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Step 1: Prep
struct PrepStepView: View {
    @EnvironmentObject var manager: RecipeManager
    let recipe: Recipe
    @State private var showItems = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Step 1: Gather Ingredients").font(.title2.bold())
            
            // Dynamically load the emojis for this specific recipe!
            HStack(spacing: 15) {
                let items = manager.availableIngredients.filter { recipe.requiredIngredients.contains($0.name) }
                
                ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                    IngredientBubble(emoji: item.emoji, delay: Double(index) * 0.2, show: showItems)
                }
            }
//            Season Logic:
            if !recipe.seasoningsBefore.isEmpty {
                VStack(spacing: 5) {
//                    Prompt user to add cooking ingredients:
                    Text("Season Add Before Cooking:")
                        .font(.headline)
                    Text(recipe.seasoningsBefore.joined(separator: ", "))
                        .foregroundColor(.orange)
                        .font(.title3.bold())
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.orange.opacity(0.1)))
            }
            
            Text("Swipe to prep! 👉").foregroundColor(.gray).padding(.top, 40)
        }
        .onAppear { showItems = true }
    }
}

struct IngredientBubble: View {
    let emoji: String; let delay: Double; let show: Bool
    var body: some View {
        Text(emoji).font(.system(size: 45)).padding(15)
            .background(Circle().fill(Color.white).shadow(radius: 5))
            .scaleEffect(show ? 1 : 0.001)
            .animation(.spring(response: 0.5, dampingFraction: 0.6).delay(delay), value: show)
    }
}

// MARK: - Step 2: Chop
struct ChopStepView: View {
    @EnvironmentObject var manager: RecipeManager
    let recipe: Recipe
    
    @State private var isChopping = false
    @State private var currentIndex = 0
    
    let switchTimer = Timer.publish(every: 1.5, on: .main, in: .common).autoconnect()
    
    var body: some View {
        // Grab the actual ingredient objects so we have both the emoji AND the name!
        let itemsToChop = manager.availableIngredients.filter { recipe.requiredIngredients.contains($0.name) }
        
        // Use the saved style, or default to "Chop" if it's an old recipe
        let actionWord = recipe.cutStyle ?? "Chop"
        
        VStack(spacing: 40) {
            Text("Step 2: Prep time!").font(.title2.bold())
            
            ZStack {
                Text("🔪").font(.system(size: 100))
                    .rotationEffect(.degrees(isChopping ? -20 : 30))
                    .offset(x: 20, y: isChopping ? 20 : -50)
                
                if !itemsToChop.isEmpty {
                    // Show the dynamic emoji!
                    Text(itemsToChop[currentIndex].emoji)
                        .font(.system(size: 60))
                        .offset(x: -20, y: 40)
                        .id("emoji-\(currentIndex)") // Forces a clean transition animation
                        .transition(.asymmetric(insertion: .scale.combined(with: .opacity), removal: .scale(scale: 0.1).combined(with: .opacity)))
                } else {
                    Text("🧅").font(.system(size: 60)).offset(x: -20, y: 40)
                }
            }
            .frame(height: 200)
            
            // Dynamic Instruction Text!
            if !itemsToChop.isEmpty {
                Text("\(actionWord) the \(itemsToChop[currentIndex].name)!")
                    .font(.title3.bold())
                    .foregroundColor(.orange)
                    .id("text-\(currentIndex)") // Animates the text changing too!
                    .transition(.opacity)
            } else {
                Text("\(actionWord) chop chop!").font(.headline).foregroundColor(.orange)
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 0.35).repeatForever(autoreverses: true)) {
                isChopping.toggle()
            }
        }
        .onReceive(switchTimer) { _ in
            if !itemsToChop.isEmpty {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                    // Loop back to the start when we reach the end of the ingredients
                    currentIndex = (currentIndex + 1) % itemsToChop.count
                }
            }
        }
    }
}

// MARK: - Step 3: Cook with Timer
struct CookStepView: View {
    let recipe: Recipe
    @State private var isCooking = false
    @State private var timeRemaining: Int = 0
    @State private var isTimerRunning = false
    
    // We use this to track if the user has manually pressed "Start"
    @State private var hasStarted = false
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 40) {
            Text("Step 3: \(recipe.method) time!").font(.title2.bold())
//            During cooking Seasoning:
            if !recipe.seasoningsDuring.isEmpty {
                Text("Throw in: \(recipe.seasoningsDuring.joined(separator: ", "))")
                    .font(.headline)
                    .foregroundColor(.gray)
            }
            
            ZStack {
                if recipe.method == "Fry" {
                    Text("🔥").font(.system(size: 100)).offset(y: 60).scaleEffect(isCooking ? 1.2 : 0.8).opacity(isCooking ? 1.0 : 0.7)
                    Text("🍳").font(.system(size: 140))
                } else if recipe.method == "Boil" {
                    Text("🍲").font(.system(size: 140))
                    Text("🫧").font(.system(size: 60)).offset(y: isCooking ? -80 : 0).opacity(isCooking ? 0 : 1)
                } else {
                    Text("🎛️").font(.system(size: 140))
                    RoundedRectangle(cornerRadius: 10).fill(Color.orange.opacity(isCooking ? 0.6 : 0.2)).frame(width: 100, height: 60).offset(y: 20)
                }
            }
            .frame(height: 250)
            
            VStack {
                // If they haven't started yet, show the "Start" button
                if !hasStarted {
                    Button {
                        // START THE TIMER MANUALLY
                        hasStarted = true
                        isTimerRunning = true
                        withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) { isCooking.toggle() }
                    } label: {
                        Text("Start Timer")
                            .font(.title3.bold())
                            .foregroundColor(.white)
                            .padding(.vertical, 12)
                            .padding(.horizontal, 30)
                            .background(Color.orange)
                            .cornerRadius(10)
                    }
                    .transition(.scale.combined(with: .opacity))
                }
                // Once started, show the countdown
                else if timeRemaining > 0 {
                    Text(String(format: "%02d:%02d", timeRemaining / 60, timeRemaining % 60))
                        .font(.system(size: 40, weight: .bold, design: .monospaced))
                        .foregroundColor(.orange)
                        .transition(.scale.combined(with: .opacity))
                        .onTapGesture {
                            timeRemaining = 1
                        }
                }
                // When done, show the Done text and play the sound
                else {
                    Text("Done! Swipe 👉")
                        .font(.title2.bold())
                        .foregroundColor(.green)
                        .transition(.scale.combined(with: .opacity))
                        .onAppear {
                            AudioServicesPlaySystemSound(1022)
                            UINotificationFeedbackGenerator().notificationOccurred(.success)
                        }
                }
            }
            .frame(height: 60)
            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: hasStarted)
            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: timeRemaining > 0)
        }
        .onAppear {
            // We set the initial time, but DO NOT start it running!
            timeRemaining = recipe.cookTime * 60
        }
        .onReceive(timer) { _ in
            if isTimerRunning && timeRemaining > 0 {
                timeRemaining -= 1
            }
            else if timeRemaining == 0 {
                isTimerRunning = false
            }
        }
    }
}


// MARK: - Step 4: Finish
struct FinishStepView: View {
    @EnvironmentObject var manager: RecipeManager
    @Environment(\.dismiss) var dismiss
    
    let recipe: Recipe
    @State private var isPlated = false
    
    // NEW: Checks if we need to pause for post-cooking seasoning!
    @State private var hasFinishedPostSeasoning = false
    
    var body: some View {
        VStack(spacing: 30) {
            
            // IF THEY HAVE AFTER-SEASONINGS, PAUSE AND SHOW THIS:
            if !recipe.seasoningsAfter.isEmpty && !hasFinishedPostSeasoning {
                Text("Wait! Final Touch!").font(.largeTitle.bold())
                
                Text("Add \(recipe.seasoningsAfter.joined(separator: ", "))")
                    .font(.title2)
                    .foregroundColor(.orange)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 15).fill(Color.white).shadow(radius: 5))
                
                Button("Done Seasoning!") {
                    withAnimation {
                        hasFinishedPostSeasoning = true
                        isPlated = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)
                .padding(.top, 20)
            }
            // OTHERWISE, SHOW THE GLORIOUS TADA SCREEN:
            else {
                Text("Tada! 🎉").font(.system(size: 40, weight: .heavy, design: .rounded))
                
                Text(recipe.emoji)
                    .font(.system(size: 150))
                    .scaleEffect(isPlated ? 1.0 : 0.5)
                    .opacity(isPlated ? 1 : 0)
                
                Text(recipe.name).font(.title.bold()).foregroundColor(.black)
                
                if isPlated {
                    Button("Back to Kitchen") {
                        manager.clearPot()
                        manager.resetNavigation = true
                        dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .controlSize(.large)
                    .padding(.top, 20)
                    .transition(.scale.combined(with: .opacity))
                }
            }
        }
        .onAppear {
            // If there are no after-seasonings, instantly skip to the Tada screen!
            if recipe.seasoningsAfter.isEmpty {
                hasFinishedPostSeasoning = true
                withAnimation(.spring(response: 0.6, dampingFraction: 0.5)) { isPlated = true }
            }
        }
    }
}
